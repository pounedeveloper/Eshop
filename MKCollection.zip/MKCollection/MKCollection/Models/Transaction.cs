﻿using System;
using System.Collections.Generic;

namespace MKCollection.Models;

public partial class Transaction
{
    public long Id { get; set; }

    public double TotalPrice { get; set; }

    public double PaidPrice { get; set; }

    public double? DiscountAmount { get; set; }

    public double? Tax { get; set; }

    public long TransactionType { get; set; }

    public DateTime Date { get; set; }

    public bool IsDefrayed { get; set; }

    public long InvoiceId { get; set; }

    public long CustomerAddressId { get; set; }

    public virtual CustomerAddress CustomerAddress { get; set; } = null!;

    public virtual ICollection<ElectronicPaymentLog> ElectronicPaymentLogs { get; set; } = new List<ElectronicPaymentLog>();

    public virtual ICollection<ElectronicPayment> ElectronicPayments { get; set; } = new List<ElectronicPayment>();

    public virtual Invoice Invoice { get; set; } = null!;

    public virtual EnumerableValue TransactionTypeNavigation { get; set; } = null!;
}
