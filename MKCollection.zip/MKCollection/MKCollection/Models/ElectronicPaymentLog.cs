﻿using System;
using System.Collections.Generic;

namespace MKCollection.Models;

public partial class ElectronicPaymentLog
{
    public long Id { get; set; }

    public long CustomerId { get; set; }

    public long TransactionId { get; set; }

    public double Price { get; set; }

    public long? Status { get; set; }

    public DateTime PayDate { get; set; }

    public long? ResNum { get; set; }

    public string? RefNum { get; set; }

    public string? Input { get; set; }

    public string? Result { get; set; }

    public virtual Customer Customer { get; set; } = null!;

    public virtual EnumerableValue? StatusNavigation { get; set; }

    public virtual Transaction Transaction { get; set; } = null!;
}
