﻿using System;
using System.Collections.Generic;

namespace MKCollection.Models;

public partial class Attachment
{
    public long Id { get; set; }

    public string? FileName { get; set; }

    public byte[]? Data { get; set; }

    public byte[]? Thumbnail { get; set; }

    public string? ContentType { get; set; }

    public virtual ICollection<Category> Categories { get; set; } = new List<Category>();

    public virtual ICollection<ProductAttachment> ProductAttachments { get; set; } = new List<ProductAttachment>();

    public virtual ICollection<ProductDetail> ProductDetails { get; set; } = new List<ProductDetail>();

    public virtual ICollection<Product> Products { get; set; } = new List<Product>();
}
