﻿using System;
using System.Collections.Generic;

namespace MKCollection.Models;

public partial class Discount
{
    public long Id { get; set; }

    public string Title { get; set; } = null!;

    public double? Percentage { get; set; }

    public double? Amount { get; set; }

    public DateTime FromDate { get; set; }

    public DateTime ExpirationDate { get; set; }

    public bool IsActive { get; set; }

    public virtual ICollection<ProductPrice> ProductPrices { get; set; } = new List<ProductPrice>();
}
