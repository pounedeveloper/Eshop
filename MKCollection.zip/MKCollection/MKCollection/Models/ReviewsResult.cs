﻿using MKCollection.Transfer.Review;

namespace MKCollection.Models
{
    public class ReviewMinimal
    {
        public int id { get; set; }
        public string ss { get; set; }
    }
    public class ReviewsResult
    {
        public int CountOfAllReviews { get; set; }
        public double AverageRating { get; set; }
        public List<ReviewsByProductResult> SlicedReviews { get; set; }
    }
}
