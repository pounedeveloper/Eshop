﻿using System;
using System.Collections.Generic;

namespace MKCollection.Models;

public partial class InvoiceStatus
{
    public long Id { get; set; }

    public long InvoiceId { get; set; }

    public long Status { get; set; }

    public DateTime Date { get; set; }

    public virtual Invoice Invoice { get; set; } = null!;

    public virtual EnumerableValue StatusNavigation { get; set; } = null!;
}
