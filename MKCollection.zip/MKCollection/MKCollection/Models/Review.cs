﻿using System;
using System.Collections.Generic;

namespace MKCollection.Models;

public partial class Review
{
    public long Id { get; set; }

    public long ProductId { get; set; }

    public long CustomerId { get; set; }

    public byte? Rating { get; set; }

    public string? Comment { get; set; }

    public DateTime DateAndTime { get; set; }

    public virtual Customer Customer { get; set; } = null!;

    public virtual Product Product { get; set; } = null!;
}
