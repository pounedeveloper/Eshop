﻿using System;
using System.Collections.Generic;

namespace MKCollection.Models;

public partial class ExceptionLog
{
    public long Id { get; set; }

    public string? ClientIp { get; set; }

    public string? UserName { get; set; }

    public DateTime? LogTime { get; set; }

    public string? ExceptionData { get; set; }

    public string? RequestUrl { get; set; }
}
