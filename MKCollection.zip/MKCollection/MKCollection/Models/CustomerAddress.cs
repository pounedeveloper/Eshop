﻿using System;
using System.Collections.Generic;

namespace MKCollection.Models;

public partial class CustomerAddress
{
    public long Id { get; set; }

    public long CustomerId { get; set; }

    public long CityId { get; set; }

    public string? PostalCode { get; set; }

    public string Address { get; set; } = null!;

    public bool IsActive { get; set; }

    public virtual City City { get; set; } = null!;

    public virtual Customer Customer { get; set; } = null!;

    public virtual ICollection<Transaction> Transactions { get; set; } = new List<Transaction>();
}
