﻿using System;
using System.Collections.Generic;

namespace MKCollection.Models;

public partial class Slide
{
    public long Id { get; set; }

    public string Code { get; set; } = null!;

    public long AttachmentId { get; set; }

    public string? Tag { get; set; }

    public int SlideIndex { get; set; }

    public bool IsActive { get; set; }

    public string? Description { get; set; }
}
