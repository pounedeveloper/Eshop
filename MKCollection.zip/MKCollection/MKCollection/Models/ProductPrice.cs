﻿using System;
using System.Collections.Generic;

namespace MKCollection.Models;

public partial class ProductPrice
{
    public long Id { get; set; }

    public long? ProductId { get; set; }

    public long? ProductDetailId { get; set; }

    public DateTime Date { get; set; }

    public double Price { get; set; }

    public long? DiscountId { get; set; }

    public long SaleType { get; set; }

    public virtual Discount? Discount { get; set; }

    public virtual Product? Product { get; set; }

    public virtual ProductDetail? ProductDetail { get; set; }

    public virtual EnumerableValue SaleTypeNavigation { get; set; } = null!;
}
