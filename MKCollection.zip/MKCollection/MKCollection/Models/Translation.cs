﻿using System;
using System.Collections.Generic;

namespace MKCollection.Models;

public partial class Translation
{
    public long Id { get; set; }

    public string? PersianTitle { get; set; }

    public string? EnglishTitle { get; set; }

    public string? TitleKey { get; set; }

    public string? Description { get; set; }
}
