﻿using System;
using System.Collections.Generic;

namespace MKCollection.Models;

public partial class Attribute
{
    public long Id { get; set; }

    public long? Title { get; set; }

    public string? Value { get; set; }

    public long ProductDetailId { get; set; }

    public virtual ProductDetail ProductDetail { get; set; } = null!;
}
