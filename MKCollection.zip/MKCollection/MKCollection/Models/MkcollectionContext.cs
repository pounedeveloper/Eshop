﻿using Microsoft.EntityFrameworkCore;

namespace MKCollection.Models;

public partial class MkcollectionContext : DbContext
{
    public MkcollectionContext()
    {
    }

    public MkcollectionContext(DbContextOptions<MkcollectionContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Attachment> Attachments { get; set; }

    public virtual DbSet<Attribute> Attributes { get; set; }

    public virtual DbSet<Category> Categories { get; set; }

    public virtual DbSet<City> Cities { get; set; }

    public virtual DbSet<Collection> Collections { get; set; }

    public virtual DbSet<Customer> Customers { get; set; }

    public virtual DbSet<CustomerActivation> CustomerActivations { get; set; }

    public virtual DbSet<CustomerAddress> CustomerAddresses { get; set; }

    public virtual DbSet<Discount> Discounts { get; set; }

    public virtual DbSet<ElectronicPayment> ElectronicPayments { get; set; }

    public virtual DbSet<ElectronicPaymentLog> ElectronicPaymentLogs { get; set; }

    public virtual DbSet<Enumerable> Enumerables { get; set; }

    public virtual DbSet<EnumerableValue> EnumerableValues { get; set; }

    public virtual DbSet<ExceptionLog> ExceptionLogs { get; set; }

    public virtual DbSet<Invoice> Invoices { get; set; }

    public virtual DbSet<InvoiceDetail> InvoiceDetails { get; set; }

    public virtual DbSet<InvoiceStatus> InvoiceStatuses { get; set; }

    public virtual DbSet<ModificationLog> ModificationLogs { get; set; }

    public virtual DbSet<Product> Products { get; set; }

    public virtual DbSet<ProductAttachment> ProductAttachments { get; set; }

    public virtual DbSet<ProductCategory> ProductCategories { get; set; }

    public virtual DbSet<ProductCollection> ProductCollections { get; set; }

    public virtual DbSet<ProductDetail> ProductDetails { get; set; }

    public virtual DbSet<ProductPrice> ProductPrices { get; set; }

    public virtual DbSet<Review> Reviews { get; set; }

    public virtual DbSet<Role> Roles { get; set; }

    public virtual DbSet<Slide> Slides { get; set; }

    public virtual DbSet<Transaction> Transactions { get; set; }

    public virtual DbSet<Translation> Translations { get; set; }

    public virtual DbSet<User> Users { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        IConfigurationRoot configuration = new ConfigurationBuilder()
                   .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
                   .AddJsonFile("appsettings.json")
                   .Build();
        optionsBuilder.UseSqlServer(configuration.GetConnectionString("SqlServerConnection"));
        optionsBuilder.UseLazyLoadingProxies();
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Attachment>(entity =>
        {
            entity.ToTable("Attachment");
        });

        modelBuilder.Entity<Attribute>(entity =>
        {
            entity.ToTable("Attribute");

            entity.Property(e => e.Value).HasMaxLength(256);

            entity.HasOne(d => d.ProductDetail).WithMany(p => p.Attributes)
                .HasForeignKey(d => d.ProductDetailId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Attribute_ProductDetail");
        });

        modelBuilder.Entity<Category>(entity =>
        {
            entity.ToTable("Category");

            entity.Property(e => e.Title).HasMaxLength(256);

            entity.HasOne(d => d.Attachment).WithMany(p => p.Categories)
                .HasForeignKey(d => d.AttachmentId)
                .HasConstraintName("FK_Category_Attachment");
        });

        modelBuilder.Entity<City>(entity =>
        {
            entity.ToTable("City");

            entity.Property(e => e.Title).HasMaxLength(256);

            entity.HasOne(d => d.Province).WithMany(p => p.InverseProvince)
                .HasForeignKey(d => d.ProvinceId)
                .HasConstraintName("FK_City_City_Province");
        });

        modelBuilder.Entity<Collection>(entity =>
        {
            entity.ToTable("Collection");

            entity.Property(e => e.Code).HasMaxLength(256);
            entity.Property(e => e.Title).HasMaxLength(256);
        });

        modelBuilder.Entity<Customer>(entity =>
        {
            entity.ToTable("Customer");

            entity.Property(e => e.Email).HasMaxLength(256);
            entity.Property(e => e.FirstName).HasMaxLength(256);
            entity.Property(e => e.LastName).HasMaxLength(256);
            entity.Property(e => e.Password).HasMaxLength(256);
            entity.Property(e => e.PhoneNumber)
                .HasMaxLength(11)
                .IsUnicode(false);
            entity.Property(e => e.RegistrationDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<CustomerActivation>(entity =>
        {
            entity.ToTable("CustomerActivation");

            entity.Property(e => e.ActivationCode).HasMaxLength(50);
            entity.Property(e => e.ActivationDate).HasColumnType("datetime");
        });

        modelBuilder.Entity<CustomerAddress>(entity =>
        {
            entity.ToTable("CustomerAddress");

            entity.Property(e => e.PostalCode)
                .HasMaxLength(10)
                .IsUnicode(false);

            entity.HasOne(d => d.City).WithMany(p => p.CustomerAddresses)
                .HasForeignKey(d => d.CityId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_CustomerAddress_City");

            entity.HasOne(d => d.Customer).WithMany(p => p.CustomerAddresses)
                .HasForeignKey(d => d.CustomerId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_CustomerAddress_Customer");
        });

        modelBuilder.Entity<Discount>(entity =>
        {
            entity.ToTable("Discount");

            entity.Property(e => e.ExpirationDate).HasColumnType("datetime");
            entity.Property(e => e.FromDate).HasColumnType("datetime");
            entity.Property(e => e.Title).HasMaxLength(256);
        });

        modelBuilder.Entity<ElectronicPayment>(entity =>
        {
            entity.ToTable("ElectronicPayment");

            entity.Property(e => e.PayDate).HasColumnType("datetime");
            entity.Property(e => e.RefNum).HasMaxLength(256);

            entity.HasOne(d => d.Customer).WithMany(p => p.ElectronicPayments)
                .HasForeignKey(d => d.CustomerId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ElectronicPayment_Customer");

            entity.HasOne(d => d.StatusNavigation).WithMany(p => p.ElectronicPayments)
                .HasForeignKey(d => d.Status)
                .HasConstraintName("FK_ElectronicPayment_EnumerableValue");

            entity.HasOne(d => d.Transaction).WithMany(p => p.ElectronicPayments)
                .HasForeignKey(d => d.TransactionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ElectronicPayment_Transaction");
        });

        modelBuilder.Entity<ElectronicPaymentLog>(entity =>
        {
            entity.ToTable("ElectronicPaymentLog");

            entity.Property(e => e.PayDate).HasColumnType("datetime");
            entity.Property(e => e.RefNum).HasMaxLength(256);

            entity.HasOne(d => d.Customer).WithMany(p => p.ElectronicPaymentLogs)
                .HasForeignKey(d => d.CustomerId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ElectronicPaymentLog_Customer");

            entity.HasOne(d => d.StatusNavigation).WithMany(p => p.ElectronicPaymentLogs)
                .HasForeignKey(d => d.Status)
                .HasConstraintName("FK_ElectronicPaymentLog_EnumerableValue");

            entity.HasOne(d => d.Transaction).WithMany(p => p.ElectronicPaymentLogs)
                .HasForeignKey(d => d.TransactionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ElectronicPaymentLog_Transaction");
        });

        modelBuilder.Entity<Enumerable>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_MetadataEnumerable");

            entity.ToTable("Enumerable");

            entity.Property(e => e.Title).HasMaxLength(250);
        });

        modelBuilder.Entity<EnumerableValue>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_MetadataEnumerableValue");

            entity.ToTable("EnumerableValue");

            entity.HasIndex(e => new { e.EnumerableId, e.Title }, "IX_EnumerableValue").IsUnique();

            entity.HasIndex(e => new { e.Value, e.EnumerableId }, "IX_MetadataValue").IsUnique();

            entity.Property(e => e.Id).ValueGeneratedNever();
            entity.Property(e => e.IsActive).HasDefaultValue(true);
            entity.Property(e => e.Title).HasMaxLength(250);
            entity.Property(e => e.Value).HasMaxLength(250);

            entity.HasOne(d => d.Enumerable).WithMany(p => p.EnumerableValues)
                .HasForeignKey(d => d.EnumerableId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_EnumerableValue_Enumerable");

            entity.HasOne(d => d.Parent).WithMany(p => p.InverseParent)
                .HasForeignKey(d => d.ParentId)
                .HasConstraintName("FK_EnumerableValue_EnumerableValue");
        });

        modelBuilder.Entity<ExceptionLog>(entity =>
        {
            entity
                .HasNoKey()
                .ToTable("ExceptionLog");

            entity.Property(e => e.ClientIp).HasMaxLength(256);
            entity.Property(e => e.Id).ValueGeneratedOnAdd();
            entity.Property(e => e.LogTime).HasColumnType("datetime");
            entity.Property(e => e.UserName).HasMaxLength(256);
        });

        modelBuilder.Entity<Invoice>(entity =>
        {
            entity.ToTable("Invoice");

            entity.Property(e => e.CancelationDate).HasColumnType("datetime");
            entity.Property(e => e.Code).HasMaxLength(256);
            entity.Property(e => e.Date).HasColumnType("datetime");

            entity.HasOne(d => d.Customer).WithMany(p => p.Invoices)
                .HasForeignKey(d => d.CustomerId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Invoice_Customer");
        });

        modelBuilder.Entity<InvoiceDetail>(entity =>
        {
            entity.ToTable("InvoiceDetail");

            entity.HasOne(d => d.Invoice).WithMany(p => p.InvoiceDetails)
                .HasForeignKey(d => d.InvoiceId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_InvoiceDetail_Invoice");

            entity.HasOne(d => d.ProductDetail).WithMany(p => p.InvoiceDetails)
                .HasForeignKey(d => d.ProductDetailId)
                .HasConstraintName("FK_InvoiceDetail_ProductDetail");

            entity.HasOne(d => d.Product).WithMany(p => p.InvoiceDetails)
                .HasForeignKey(d => d.ProductId)
                .HasConstraintName("FK_InvoiceDetail_Product");
        });

        modelBuilder.Entity<InvoiceStatus>(entity =>
        {
            entity.ToTable("InvoiceStatus");

            entity.Property(e => e.Date).HasColumnType("datetime");

            entity.HasOne(d => d.Invoice).WithMany(p => p.InvoiceStatuses)
                .HasForeignKey(d => d.InvoiceId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_InvoiceStatus_Invoice");

            entity.HasOne(d => d.StatusNavigation).WithMany(p => p.InvoiceStatuses)
                .HasForeignKey(d => d.Status)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_InvoiceStatus_EnumerableValue");
        });

        modelBuilder.Entity<ModificationLog>(entity =>
        {
            entity.ToTable("ModificationLog");

            entity.Property(e => e.ChangeTime).HasColumnType("datetime");
            entity.Property(e => e.ChangeType).HasMaxLength(256);
            entity.Property(e => e.ClientIp).HasMaxLength(256);
            entity.Property(e => e.EntityName).HasMaxLength(256);
            entity.Property(e => e.Username).HasMaxLength(256);
        });

        modelBuilder.Entity<Product>(entity =>
        {
            entity.ToTable("Product");

            entity.Property(e => e.Code).HasMaxLength(256);
            entity.Property(e => e.Title).HasMaxLength(256);

            entity.HasOne(d => d.GenderNavigation).WithMany(p => p.ProductGenderNavigations)
                .HasForeignKey(d => d.Gender)
                .HasConstraintName("FK_Product_EnumerableValue");

            entity.HasOne(d => d.SaleTypeNavigation).WithMany(p => p.ProductSaleTypeNavigations)
                .HasForeignKey(d => d.SaleType)
                .OnDelete(DeleteBehavior.ClientSetNull);

            entity.HasOne(d => d.StatusNavigation).WithMany(p => p.ProductStatusNavigations)
                .HasForeignKey(d => d.Status)
                .OnDelete(DeleteBehavior.ClientSetNull);

            entity.HasOne(d => d.Thumbnail).WithMany(p => p.Products)
                .HasForeignKey(d => d.ThumbnailId)
                .HasConstraintName("FK_Product_Attachment");

            entity.HasOne(d => d.User).WithMany(p => p.Products)
                .HasForeignKey(d => d.UserId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Product_User");
        });

        modelBuilder.Entity<ProductAttachment>(entity =>
        {
            entity.ToTable("ProductAttachment");

            entity.HasOne(d => d.Attachment).WithMany(p => p.ProductAttachments)
                .HasForeignKey(d => d.AttachmentId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ProductAttachment_Attachment");

            entity.HasOne(d => d.ProductDetail).WithMany(p => p.ProductAttachments)
                .HasForeignKey(d => d.ProductDetailId)
                .HasConstraintName("FK_ProductAttachment_ProductDetail");

            entity.HasOne(d => d.Product).WithMany(p => p.ProductAttachments)
                .HasForeignKey(d => d.ProductId)
                .HasConstraintName("FK_ProductAttachment_Product");
        });

        modelBuilder.Entity<ProductCategory>(entity =>
        {
            entity.ToTable("ProductCategory");

            entity.HasOne(d => d.Category).WithMany(p => p.ProductCategories)
                .HasForeignKey(d => d.CategoryId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ProductCategory_Category");

            entity.HasOne(d => d.Product).WithMany(p => p.ProductCategories)
                .HasForeignKey(d => d.ProductId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ProductCategory_Product");
        });

        modelBuilder.Entity<ProductCollection>(entity =>
        {
            entity.ToTable("ProductCollection");

            entity.HasOne(d => d.Collection).WithMany(p => p.ProductCollections)
                .HasForeignKey(d => d.CollectionId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ProductCollection_Collection");

            entity.HasOne(d => d.Product).WithMany(p => p.ProductCollections)
                .HasForeignKey(d => d.ProductId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ProductCollection_Product");
        });

        modelBuilder.Entity<ProductDetail>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK_ProductVarient");

            entity.ToTable("ProductDetail");

            entity.HasOne(d => d.ColorNavigation).WithMany(p => p.ProductDetailColorNavigations).HasForeignKey(d => d.Color);

            entity.HasOne(d => d.Product).WithMany(p => p.ProductDetails)
                .HasForeignKey(d => d.ProductId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ProductDetail_Product");

            entity.HasOne(d => d.SizeNavigation).WithMany(p => p.ProductDetailSizeNavigations).HasForeignKey(d => d.Size);

            entity.HasOne(d => d.StatusNavigation).WithMany(p => p.ProductDetailStatusNavigations)
                .HasForeignKey(d => d.Status)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ProductDetail_EnumerableValue");

            entity.HasOne(d => d.Thumbnail).WithMany(p => p.ProductDetails)
                .HasForeignKey(d => d.ThumbnailId)
                .HasConstraintName("FK_ProductDetail_Attachment");
        });

        modelBuilder.Entity<ProductPrice>(entity =>
        {
            entity.ToTable("ProductPrice");

            entity.Property(e => e.Date).HasColumnType("datetime");

            entity.HasOne(d => d.Discount).WithMany(p => p.ProductPrices)
                .HasForeignKey(d => d.DiscountId)
                .HasConstraintName("FK_ProductPrice_Discount");

            entity.HasOne(d => d.ProductDetail).WithMany(p => p.ProductPrices)
                .HasForeignKey(d => d.ProductDetailId)
                .HasConstraintName("FK_ProductPrice_ProductDetail");

            entity.HasOne(d => d.Product).WithMany(p => p.ProductPrices)
                .HasForeignKey(d => d.ProductId)
                .HasConstraintName("FK_ProductPrice_Product");

            entity.HasOne(d => d.SaleTypeNavigation).WithMany(p => p.ProductPrices)
                .HasForeignKey(d => d.SaleType)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_ProductPrice_EnumerableValue");
        });

        modelBuilder.Entity<Review>(entity =>
        {
            entity.ToTable("Review");

            entity.Property(e => e.DateAndTime).HasColumnType("datetime");

            entity.HasOne(d => d.Customer).WithMany(p => p.Reviews)
                .HasForeignKey(d => d.CustomerId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Review_Customer");

            entity.HasOne(d => d.Product).WithMany(p => p.Reviews)
                .HasForeignKey(d => d.ProductId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Review_Product");
        });

        modelBuilder.Entity<Role>(entity =>
        {
            entity.ToTable("Role");

            entity.Property(e => e.Title).HasMaxLength(256);
        });

        modelBuilder.Entity<Slide>(entity =>
        {
            entity.ToTable("Slide");

            entity.Property(e => e.Code).HasMaxLength(256);
            entity.Property(e => e.Tag).HasMaxLength(256);
        });

        modelBuilder.Entity<Transaction>(entity =>
        {
            entity.ToTable("Transaction");

            entity.Property(e => e.Date).HasColumnType("datetime");

            entity.HasOne(d => d.CustomerAddress).WithMany(p => p.Transactions)
                .HasForeignKey(d => d.CustomerAddressId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Transaction_CustomerAddress");

            entity.HasOne(d => d.Invoice).WithMany(p => p.Transactions)
                .HasForeignKey(d => d.InvoiceId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Transaction_Invoice");

            entity.HasOne(d => d.TransactionTypeNavigation).WithMany(p => p.Transactions)
                .HasForeignKey(d => d.TransactionType)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_Transaction_EnumerableValue");
        });

        modelBuilder.Entity<Translation>(entity =>
        {
            entity.ToTable("Translation");

            entity.Property(e => e.EnglishTitle).HasMaxLength(256);
            entity.Property(e => e.PersianTitle).HasMaxLength(256);
            entity.Property(e => e.TitleKey).HasMaxLength(256);
        });

        modelBuilder.Entity<User>(entity =>
        {
            entity.ToTable("User");

            entity.Property(e => e.FirstName).HasMaxLength(256);
            entity.Property(e => e.LastName).HasMaxLength(256);
            entity.Property(e => e.NationalCode).HasMaxLength(11);
            entity.Property(e => e.Password).HasMaxLength(256);
            entity.Property(e => e.Username).HasMaxLength(256);

            entity.HasOne(d => d.Role).WithMany(p => p.Users)
                .HasForeignKey(d => d.RoleId)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_User_Role");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
