﻿using System;
using System.Collections.Generic;

namespace MKCollection.Models;

public partial class InvoiceDetail
{
    public long Id { get; set; }

    public long InvoiceId { get; set; }

    public long? ProductId { get; set; }

    public long? ProductDetailId { get; set; }

    public int Count { get; set; }

    public double TotalPrice { get; set; }

    public double PaidPrice { get; set; }

    public double? Discount { get; set; }

    public virtual Invoice Invoice { get; set; } = null!;

    public virtual Product? Product { get; set; }

    public virtual ProductDetail? ProductDetail { get; set; }
}
