﻿using System;
using System.Collections.Generic;

namespace MKCollection.Models;

public partial class Product
{
    public long Id { get; set; }

    public string Title { get; set; } = null!;

    public string Code { get; set; } = null!;

    public long? ThumbnailId { get; set; }

    public bool IsMenu { get; set; }

    public long? Gender { get; set; }

    public string? Description { get; set; }

    public long SaleType { get; set; }

    public long UserId { get; set; }

    public double? Weight { get; set; }

    public int? Height { get; set; }

    public long Status { get; set; }

    public virtual EnumerableValue? GenderNavigation { get; set; }

    public virtual ICollection<InvoiceDetail> InvoiceDetails { get; set; } = new List<InvoiceDetail>();

    public virtual ICollection<ProductAttachment> ProductAttachments { get; set; } = new List<ProductAttachment>();

    public virtual ICollection<ProductCategory> ProductCategories { get; set; } = new List<ProductCategory>();

    public virtual ICollection<ProductCollection> ProductCollections { get; set; } = new List<ProductCollection>();

    public virtual ICollection<ProductDetail> ProductDetails { get; set; } = new List<ProductDetail>();

    public virtual ICollection<ProductPrice> ProductPrices { get; set; } = new List<ProductPrice>();

    public virtual ICollection<Review> Reviews { get; set; } = new List<Review>();

    public virtual EnumerableValue SaleTypeNavigation { get; set; } = null!;

    public virtual EnumerableValue StatusNavigation { get; set; } = null!;

    public virtual Attachment? Thumbnail { get; set; }

    public virtual User User { get; set; } = null!;
}
