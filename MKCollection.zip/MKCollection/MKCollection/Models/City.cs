﻿using System;
using System.Collections.Generic;

namespace MKCollection.Models;

public partial class City
{
    public long Id { get; set; }

    public string Title { get; set; } = null!;

    public long? ProvinceId { get; set; }

    public virtual ICollection<CustomerAddress> CustomerAddresses { get; set; } = new List<CustomerAddress>();

    public virtual ICollection<City> InverseProvince { get; set; } = new List<City>();

    public virtual City? Province { get; set; }
}
