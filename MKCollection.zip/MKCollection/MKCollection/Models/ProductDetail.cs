﻿using System;
using System.Collections.Generic;

namespace MKCollection.Models;

public partial class ProductDetail
{
    public long Id { get; set; }

    public long ProductId { get; set; }

    public long? ThumbnailId { get; set; }

    public long? Size { get; set; }

    public long? Color { get; set; }

    public int Quantity { get; set; }

    public int Stock { get; set; }

    public bool InMenu { get; set; }

    public long Status { get; set; }

    public virtual ICollection<Attribute> Attributes { get; set; } = new List<Attribute>();

    public virtual EnumerableValue? ColorNavigation { get; set; }

    public virtual ICollection<InvoiceDetail> InvoiceDetails { get; set; } = new List<InvoiceDetail>();

    public virtual Product Product { get; set; } = null!;

    public virtual ICollection<ProductAttachment> ProductAttachments { get; set; } = new List<ProductAttachment>();

    public virtual ICollection<ProductPrice> ProductPrices { get; set; } = new List<ProductPrice>();

    public virtual EnumerableValue? SizeNavigation { get; set; }

    public virtual EnumerableValue StatusNavigation { get; set; } = null!;

    public virtual Attachment? Thumbnail { get; set; }
}
