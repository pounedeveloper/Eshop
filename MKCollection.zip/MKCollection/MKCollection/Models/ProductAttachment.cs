﻿using System;
using System.Collections.Generic;

namespace MKCollection.Models;

public partial class ProductAttachment
{
    public long Id { get; set; }

    public long AttachmentId { get; set; }

    public long? ProductId { get; set; }

    public long? ProductDetailId { get; set; }

    public bool IsActive { get; set; }

    public virtual Attachment Attachment { get; set; } = null!;

    public virtual Product? Product { get; set; }

    public virtual ProductDetail? ProductDetail { get; set; }
}
