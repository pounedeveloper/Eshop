﻿using System;
using System.Collections.Generic;

namespace MKCollection.Models;

public partial class Customer
{
    public long Id { get; set; }

    public string FirstName { get; set; } = null!;

    public string LastName { get; set; } = null!;

    public string Password { get; set; } = null!;

    public string PhoneNumber { get; set; } = null!;

    public string? Email { get; set; }

    public bool IsActive { get; set; }

    public DateTime RegistrationDate { get; set; }

    public virtual ICollection<CustomerAddress> CustomerAddresses { get; set; } = new List<CustomerAddress>();

    public virtual ICollection<ElectronicPaymentLog> ElectronicPaymentLogs { get; set; } = new List<ElectronicPaymentLog>();

    public virtual ICollection<ElectronicPayment> ElectronicPayments { get; set; } = new List<ElectronicPayment>();

    public virtual ICollection<Invoice> Invoices { get; set; } = new List<Invoice>();

    public virtual ICollection<Review> Reviews { get; set; } = new List<Review>();
}
