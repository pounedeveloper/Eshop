﻿using System;
using System.Collections.Generic;

namespace MKCollection.Models;

public partial class Invoice
{
    public long Id { get; set; }

    public string Code { get; set; } = null!;

    public long CustomerId { get; set; }

    public DateTime Date { get; set; }

    public DateTime? CancelationDate { get; set; }

    public int TotalCount { get; set; }

    public double TotalPrice { get; set; }

    public double PaidPrice { get; set; }

    public virtual Customer Customer { get; set; } = null!;

    public virtual ICollection<InvoiceDetail> InvoiceDetails { get; set; } = new List<InvoiceDetail>();

    public virtual ICollection<InvoiceStatus> InvoiceStatuses { get; set; } = new List<InvoiceStatus>();

    public virtual ICollection<Transaction> Transactions { get; set; } = new List<Transaction>();
}
