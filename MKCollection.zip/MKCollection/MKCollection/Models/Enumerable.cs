﻿using System;
using System.Collections.Generic;

namespace MKCollection.Models;

public partial class Enumerable
{
    public long Id { get; set; }

    public string Title { get; set; } = null!;

    public string? Description { get; set; }

    public virtual ICollection<EnumerableValue> EnumerableValues { get; set; } = new List<EnumerableValue>();
}
