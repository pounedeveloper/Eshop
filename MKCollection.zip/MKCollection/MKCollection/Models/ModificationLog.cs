﻿using System;
using System.Collections.Generic;

namespace MKCollection.Models;

public partial class ModificationLog
{
    public long Id { get; set; }

    public string EntityName { get; set; } = null!;

    public long RecordId { get; set; }

    public string ChangeType { get; set; } = null!;

    public DateTime ChangeTime { get; set; }

    public long ModifierId { get; set; }

    public string? RecordData { get; set; }

    public string? ClientIp { get; set; }

    public string? Username { get; set; }
}
