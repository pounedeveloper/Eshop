﻿using System;
using System.Collections.Generic;

namespace MKCollection.Models;

public partial class Collection
{
    public long Id { get; set; }

    public string Title { get; set; } = null!;

    public string Code { get; set; } = null!;

    public bool IsActive { get; set; }

    public bool InMenu { get; set; }

    public virtual ICollection<ProductCollection> ProductCollections { get; set; } = new List<ProductCollection>();
}
