﻿using System;
using System.Collections.Generic;

namespace MKCollection.Models;

public partial class ProductCollection
{
    public long Id { get; set; }

    public long ProductId { get; set; }

    public long CollectionId { get; set; }

    public virtual Collection Collection { get; set; } = null!;

    public virtual Product Product { get; set; } = null!;
}
