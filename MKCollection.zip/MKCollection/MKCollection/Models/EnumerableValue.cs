﻿using System;
using System.Collections.Generic;

namespace MKCollection.Models;

public partial class EnumerableValue
{
    public long Id { get; set; }

    public string Value { get; set; } = null!;

    public string Title { get; set; } = null!;

    public long EnumerableId { get; set; }

    public long? ParentId { get; set; }

    public string? Description { get; set; }

    public string? UserField01 { get; set; }

    public string? UserField02 { get; set; }

    public string? UserField03 { get; set; }

    public bool IsSystemic { get; set; }

    public bool IsActive { get; set; }

    public virtual ICollection<ElectronicPaymentLog> ElectronicPaymentLogs { get; set; } = new List<ElectronicPaymentLog>();

    public virtual ICollection<ElectronicPayment> ElectronicPayments { get; set; } = new List<ElectronicPayment>();

    public virtual Enumerable Enumerable { get; set; } = null!;

    public virtual ICollection<EnumerableValue> InverseParent { get; set; } = new List<EnumerableValue>();

    public virtual ICollection<InvoiceStatus> InvoiceStatuses { get; set; } = new List<InvoiceStatus>();

    public virtual EnumerableValue? Parent { get; set; }

    public virtual ICollection<ProductDetail> ProductDetailColorNavigations { get; set; } = new List<ProductDetail>();

    public virtual ICollection<ProductDetail> ProductDetailSizeNavigations { get; set; } = new List<ProductDetail>();

    public virtual ICollection<ProductDetail> ProductDetailStatusNavigations { get; set; } = new List<ProductDetail>();

    public virtual ICollection<Product> ProductGenderNavigations { get; set; } = new List<Product>();

    public virtual ICollection<ProductPrice> ProductPrices { get; set; } = new List<ProductPrice>();

    public virtual ICollection<Product> ProductSaleTypeNavigations { get; set; } = new List<Product>();

    public virtual ICollection<Product> ProductStatusNavigations { get; set; } = new List<Product>();

    public virtual ICollection<Transaction> Transactions { get; set; } = new List<Transaction>();
}
