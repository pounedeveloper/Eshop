﻿using MKCollection.Models;
using System;
using System.Collections.Generic;

namespace MKCollection.Models
{
    public partial class CustomerActivation
    {
        public long Id { get; set; }
        public long CustomerId { get; set; }
        public string ActivationCode { get; set; } = null!;
        public DateTime ActivationDate { get; set; }

        public virtual Customer? Customer { get; set; } = null!;
    }
}