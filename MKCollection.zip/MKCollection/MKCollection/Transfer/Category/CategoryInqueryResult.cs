﻿namespace MKCollection.Transfer.Category
{
    public class CategoryInqueryResult
    {
        public long Id { get; set; }
        public bool InMenu { get; set; }
        public bool IsActive { get; set; }
        public long? AttachmentId { get; set; }
        public string Title { get; set; } = null!;
    }
}
