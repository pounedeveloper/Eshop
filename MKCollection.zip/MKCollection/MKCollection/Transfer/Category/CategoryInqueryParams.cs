﻿namespace MKCollection.Transfer.Category
{
    public class CategoryInqueryParams:Paginated
    {
        public bool? InMenu { get; set; }
        public string? Title { get; set; } 
        public bool? IsActive { get; set; }
    }
}
