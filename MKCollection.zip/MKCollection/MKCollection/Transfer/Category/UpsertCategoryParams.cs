﻿using MKCollection.Transfer.Attachment;

namespace MKCollection.Transfer.Category
{
    public class UpsertCategoryParams
    {
        public long? Id { get; set; }
        public bool InMenu { get; set; }
        public bool IsActive { get; set; }
        public long? AttachmentId { get; set; }
        public string? Description { get; set; }
        public string Title { get; set; } = null!;
        public AttachmentParam? Attachment { get; set; }
    }
}
