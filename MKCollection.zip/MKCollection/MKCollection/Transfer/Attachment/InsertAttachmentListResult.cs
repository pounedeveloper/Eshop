﻿namespace MKCollection.Transfer.Attachment
{
    public class InsertAttachmentListResult
    {
        public long? ThumbnailId { get; set; }
        public List<long> AttachmentIds { get; set; }=new List<long>();
    }
}
