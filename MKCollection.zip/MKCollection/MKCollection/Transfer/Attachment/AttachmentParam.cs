﻿namespace MKCollection.Transfer.Attachment
{
    public class AttachmentParam
    {
        public string? FileName { get; set; }
        public string Data { get; set; } = null!;
        public byte[]? Thumbnail { get; set; }
        public bool IsThumbnail { get; set; }
        public string? ContentType { get; set; }
    }
}
