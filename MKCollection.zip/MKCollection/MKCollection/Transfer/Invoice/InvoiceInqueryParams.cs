﻿namespace MKCollection.Transfer.Invoice
{
    public class InvoiceInqueryParams : Paginated
    {
        //public long? Status { get; set; }
        public string? Code { get; set; }
        public DateTime? ToDate { get; set; }
        public DateTime? FromDate { get; set; }
        public long? CustomerId { get; set; }
    }
}
