﻿namespace MKCollection.Transfer.Invoice
{
    public class AddToCartParams
    {
        public List<CartItem> Products { get; set; } = new List<CartItem>();
    }

    public class CartItem
    {
        public long ProductId { get; set; }
        public int Count { get; set; }
        public double Price { get; set; }
        public double? Discount { get; set; }
    }
}
