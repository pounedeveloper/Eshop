﻿namespace MKCollection.Transfer.Invoice
{
    public class InvoiceInqueryResult
    {
        public long Id { get; set; }
        public string? Date { get; set; }
        public double PaidPrice { get; set; }
        public double TotalPrice { get; set; }
        public string Code { get; set; } = null!;
        public string Status { get; set; } = null!;
        public long StatusId { get; set; }
        public string CustomerFullName { get; set; } = null!;
        public string CustomerPhoneNumber { get; set; } = null!;
    }
}
