﻿namespace MKCollection.Transfer.Customer
{
    public class SubmitAddressParams
    {
        public long? Id { get; set; }
        public long CityId { get; set; }
        public string? PostalCode { get; set; }
        public string Address { get; set; } = null!;

    }
}
