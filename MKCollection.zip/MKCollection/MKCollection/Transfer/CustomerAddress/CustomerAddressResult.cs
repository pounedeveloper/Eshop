﻿namespace MKCollection.Transfer.CustomerAddress
{
    public class CustomerAddressResult
    {
        public long Id { get; set; }
        public long CityId { get; set; }
        public long CustomerId { get; set; }
        public string? PostalCode { get; set; }
        public string Address { get; set; } = null!;
    }
}
