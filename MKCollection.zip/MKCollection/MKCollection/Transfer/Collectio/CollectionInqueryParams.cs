﻿namespace MKCollection.Transfer.Collectio
{
    public class CollectionInqueryParams : Paginated
    {
        public bool? InMenu { get; set; }
        public string? Title { get; set; }
        public string? Code { get; set; }
        public bool? IsActive { get; set; }
    }
}
