﻿namespace MKCollection.Transfer.Collectio
{
    public class UpsertCollectionParams
    {
        public long? Id { get; set; }
        public bool InMenu { get; set; }
        public bool IsActive { get; set; }
        public string? Description { get; set; }
        public string Title { get; set; } = null!;
        public string Code { get; set; } = null!;
    }
}
