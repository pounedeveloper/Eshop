﻿namespace MKCollection.Transfer.Collectio
{
    public class GetCollectionByIdResult
    {
        public long Id { get; set; }
        public string Title { get; set; } = null!;
        public string Code { get; set; } = null!;
        public bool IsActive { get; set; }
        public bool InMenu { get; set; }
        public string? Description { get; set; }
    }
}
