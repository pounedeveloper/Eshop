﻿namespace MKCollection.Transfer.Collectio
{
    public class CollectionInqueryResult
    {
        public long Id { get; set; }
        public bool InMenu { get; set; }
        public bool IsActive { get; set; }
        public string Title { get; set; } = null!;
        public string Code { get; set; } = null!;
    }
}
