﻿namespace MKCollection.Transfer.Review
{
    public class SubmitReviewParams
    {
        public long? Id { get; set; }
        public long ProductId { get; set; }
        public byte? Rating { get; set; }
        public string? Comment { get; set; }
    }
}
