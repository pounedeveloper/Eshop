﻿namespace MKCollection.Transfer.Review
{
    public class ReviewByIdResult
    {
        public string FirstName { get; set; } = null!;
        public string LastName { get; set; } = null!;
        public string ProductTitle { get; set; } = null!;
        public byte? Rating { get; set; }
        public DateTime? DateAndTime { get; set; }
        public string? Comment { get; set; }
    }
}
