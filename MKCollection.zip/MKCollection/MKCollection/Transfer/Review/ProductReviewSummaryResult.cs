﻿namespace MKCollection.Transfer.Review
{
    public class ProductReviewSummaryResult
    {
        public Dictionary<int, decimal> RatingPercentages { get; set; } = [];
        public double Rating { get; set; }
        public DateTime StartDate { get; set; }
        public double Renew { get; set; }
    }
}
