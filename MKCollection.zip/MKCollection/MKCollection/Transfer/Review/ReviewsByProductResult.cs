﻿using Microsoft.AspNetCore.Mvc;
using MKCollection.Models;

namespace MKCollection.Transfer.Review
{
    public class ReviewsByProductResult
    {
        public int Count { get; set; }
        public double Average { get; set; }
        public List<ReviewResult> ReviewResults { get; set; } = new List<ReviewResult>();


    }
    public class ReviewResult
    {
        public long Id { get; set; }
        public string FirstName { get; set; } = null!;
        public string LastName { get; set; } = null!;
        public byte? Rating { get; set; }
        public string? Comment { get; set; }
        public DateTime DateAndTime { get; set; }


    }
}
