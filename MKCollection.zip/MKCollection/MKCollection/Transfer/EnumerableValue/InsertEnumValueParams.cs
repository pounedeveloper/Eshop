﻿namespace MKCollection.Transfer.EnumerableValue
{
    public class InsertEnumValueParams
    {
        public string Title { get; set; } = null!;
        public long EnumerableId { get; set; }
    }
}
