﻿namespace MKCollection.Transfer.EnumerableValue
{
    public class EnumValueByEnumIdResult
    {
        public long Id { get; set; }
        public string Value { get; set; } = null!;
        public string Title { get; set; } = null!;
        public bool IsActive { get; set; }
    }
}
