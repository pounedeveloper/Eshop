﻿namespace MKCollection.Transfer.Discount
{
    public class DiscountInqueryResult
    {
        public string Title { get; set; } = null!;
        public double? Amount { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ExpirationDate { get; set; }
        public bool IsActive { get; set; }
        public string IsActiveTitle { get; set; } = null!;
    }
}
