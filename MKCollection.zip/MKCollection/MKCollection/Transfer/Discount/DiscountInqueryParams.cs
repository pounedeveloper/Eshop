﻿namespace MKCollection.Transfer.Discount
{
    public class DiscountInqueryParams : Paginated
    {
        public string? Title { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public bool? IsActive { get; set; }
    }
}
