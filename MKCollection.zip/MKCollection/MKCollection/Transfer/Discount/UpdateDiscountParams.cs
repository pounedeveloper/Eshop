﻿namespace MKCollection.Transfer.Discount
{
    public class UpdateDiscountParams
    {
        public long Id { get; set; }
        public string? Title { get; set; }
        public double? Percentage { get; set; }
        public double? Amount { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public bool? IsActive { get; set; }
        public DateTime FromDate { get; set; }
    }
}
