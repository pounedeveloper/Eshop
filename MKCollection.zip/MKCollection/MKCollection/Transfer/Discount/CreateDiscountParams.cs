﻿namespace MKCollection.Transfer.Discount
{
    public class CreateDiscountParams
    {
        public string Title { get; set; } = null!;
        public double? Percentage { get; set; }
        public double? Amount { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime ExpirationDate { get; set; }
    }
}
