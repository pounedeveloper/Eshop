﻿namespace MKCollection.Transfer.Product
{
    public class ProductResult
    {
        public long Id { get; set; }
        public string Title { get; set; } = null!;
        public string Code { get; set; } = null!;
        public long? ThumbnailId { get; set; }
        public long Status { get; set; }
        public bool IsMenu { get; set; }
        public long? Gender { get; set; }
        public string? Description { get; set; }
        public List<long>? CategoryList { get; set; } = new List<long>();
        public List<long>? CollectionList { get; set; } = new List<long>();
        public long SaleType { get; set; }
        public double? Price { get; set; }
        public double? WholeSalePrice { get; set; }
        public double? Weight { get; set; } //به کاربر نشون داده نشه
        public int? Height { get; set; }
        public List<long> AttachmentIds { get; set; } = new List<long>();
        public List<ProductDetailResult>? ProductDetails { get; set; }
    }
    public class ProductDetailResult
    {
        public long? Size { get; set; }
        public bool InMenu { get; set; }
        public long? Color { get; set; }
        public int Quantity { get; set; }
        public long Status { get; set; }
        public long? ThumbnailId { get; set; }
        public List<long>? AttachmentIds { get; set; }

    }
}
