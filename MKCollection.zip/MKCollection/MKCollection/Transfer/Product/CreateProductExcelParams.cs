﻿namespace MKCollection.Transfer.Product
{
    public class CreateProductExcelParams
    {
        public long UserId { get; set; }
        public double Price { get; set; }
        public string Code { get; set; } = null!;
        public string Title { get; set; } = null!;
        public int Quantity { get; set; }
        public string? Size { get; set; }
        public string? Color { get; set; }
    }
}
