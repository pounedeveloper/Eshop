﻿namespace MKCollection.Transfer.Product
{
    public class ProductInqueryParams : Paginated
    {
        public bool? IsMenu { get; set; }
        public long? Gender { get; set; }
        public string? Code { get; set; }
        public string? Title { get; set; }
        public long? SaleType { get; set; }
        public long? Status { get; set; }
        public List<long>? ColorList { get; set; } = new List<long>();
        public List<long>? SizeList { get; set; } = new List<long>();

        public List<long>? CategoryList { get; set; } = new List<long>();
        public List<long>? CollectionList { get; set; } = new List<long>();
        public double PriceMin { get; set; }
        public double PriceMax { get; set; }
        public double Ratings { get; set; }
        public string? OrderBy { get; set; }

    }
}
