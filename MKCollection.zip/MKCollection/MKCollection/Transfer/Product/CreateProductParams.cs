﻿using MKCollection.Transfer.Attachment;

namespace MKCollection.Transfer.Product
{
    public class CreateProductParams
    {
        public List<long>? CategoryList { get; set; } = new List<long>();
        public string? Code { get; set; } = null!;
        public List<long>? Collectionlist { get; set; } = new List<long>();
        public string? Description { get; set; }
        public bool IsMenu { get; set; }
        public long Status { get; set; }
        public double? Price { get; set; }
        public List<ProductDetailParams>? ProductDetails { get; set; } = new List<ProductDetailParams>();
        public string? Title { get; set; } = null!;
        public double? WholesalePrice { get; set; }
        public double? Weight { get; set; }
        public int? Height { get; set; }


        public long? UserId { get; set; }
        public long? Gender { get; set; }
        public long SaleType { get; set; }
        public List<AttachmentParam>? ProductAttachments { get; set; }
    }

    public class ProductDetailParams
    {
        public long? Color { get; set; }
        public bool InMenu { get; set; }
        public long Status { get; set; }
        public double? Price { get; set; }
        public int Quantity { get; set; }
        public long? Size { get; set; }
        public int Stock { get; set; }
        public double? WholesalePrice { get; set; }
        public List<AttachmentParam>? ProductAttachments { get; set; }

    }
}
