﻿namespace MKCollection.Transfer.Product
{
    public class ProductInqueryResult
    {
        public long Id { get; set; }
        public int? Stock { get; set; }
        public bool IsMenu { get; set; }
        public double? Price { get; set; }
        public double? WholeSalePrice { get; set; }
        public string? Code { get; set; }
        public string? Title { get; set; }
        public long Status { get; set; }
        public double? AverageRating { get; set; }
        public double? MaxDiscount { get; set; }
        public ThumbnailResult? Thumbnail { get; set; }
        public List<long> CategoryList { get; set; } = new List<long>();
        public List<long> CollectionList { get; set; } = new List<long>();


        public List<long?> Colors { get; set; } = new List<long?>();
        public List<long?> Sizes { get; set; } = new List<long?>();
        public int NumberOfComments { get; set; }

    }
    public class ThumbnailResult
    {
        public long Id { get; set; }
        public string? FileName { get; set; }
        public string? ContentType { get; set; }

        public string? File { get; set; }
        public string MimeType { get; set; } = null!;
    }
}
