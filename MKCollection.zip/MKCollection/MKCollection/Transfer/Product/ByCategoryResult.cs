﻿namespace MKCollection.Transfer.Product
{
    public class ByCategoryResult
    {
        public long Id { get; set; }
        public bool IsMenu { get; set; }
        public string? Code { get; set; }
        public string? Title { get; set; }
        public string StatusTitle { get; set; } = null!;
        public double? Price { get; set; }
        public long? ThumbnailId { get; set; }
        public string? GenderTitle { get; set; }
        //public string? ProviderTitle { get; set; }
        public string? CollectionTitle { get; set; }
    }
}
