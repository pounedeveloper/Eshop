﻿namespace MKCollection.Transfer.Product
{
    public class NewProductsResult
    {

        public string Title { get; set; } = null!;
        public long? ThumbnailId { get; set; }
        public string? Gender { get; set; }
        public double? Price { get; set; }
        public double? WholeSalePrice { get; set; }
        public List<string>? CategoryList { get; set; } = new List<string>();
        public List<string>? CollectionList { get; set; } = new List<string>();
        public List<long>? Colors { get; set; } = new List<long>();
        public List<long>? Sizes { get; set; } = new List<long>();

    }
}
