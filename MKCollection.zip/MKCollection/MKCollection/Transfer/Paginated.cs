﻿namespace MKCollection.Transfer;

public class Paginated
{
    public int Skip { get; set; }
    public int Limit { get; set; }
}