﻿namespace MKCollection.Transfer.Customer
{
    public class CustomerInqueryResult
    {
        public long Id { get; set; }
        public string? Email { get; set; }
        public bool IsActive { get; set; }
        public string FullName { get; set; } = null!;
        public string RegistrationDate { get; set; } = null!;
        public string PhoneNumber { get; set; } = null!;
    }
}
