﻿namespace MKCollection.Transfer.Customer
{
    public class CustomerInqueryParams:Paginated
    {
        public string? Name { get; set; } 
        public bool? IsActive { get; set; }
        public string? Username { get; set; } 
    }
}
