﻿using System.ComponentModel.DataAnnotations;

namespace MKCollection.Transfer.Customer
{
    public class CustomerModel
    {
        public class LoginModel
        {
            public string? Mobile { get; set; }
            public string? Password { get; set; }
        }
        public class LoginResult
        {
            public string? Token { get; set; }
            public string? Mobile { get; set; }
            public string? UserName { get; set; }
            public long Id { get; set; }
            public string? FullName { get; set; }
            public long ExpireTime { get; set; }
        }
        public class CustomerRegister
        {
            public string? FirstName { get; set; }

            public string? LastName { get; set; }

            public string? Password { get; set; }

            public string? PhoneNumber { get; set; }

            public string? Email { get; set; }

        }
        public class ResetPasswordViewModel
        {
            [Required]
            public string? Mobile { get; set; }

            [Required]
            [StringLength(100, ErrorMessage = "The {0} must be at least {2} characters long.", MinimumLength = 6)]
            [DataType(DataType.Password)]
            public string? Password { get; set; }
            public string? Code { get; set; }
        }
    }
}
