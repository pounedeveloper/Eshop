﻿namespace MKCollection.Transfer.Customer
{
    public class CustomerDetailsResult
    {
        public long Id { get; set; }
        public string? Email { get; set; }
        public bool IsActive { get; set; }
        public string FullName { get; set; } = null!;
        public string Username { get; set; } = null!;
        public DateTime RegistrationDate { get; set; }
        public string PhoneNumber { get; set; } = null!;

        public List<OrderHistory>? OrderHistories { get; set; }

    }

    public class OrderHistory
    {
        public long InvoiceId { get; set; }
        public string Code { get; set; } = null!;
        public DateTime Date { get; set; }
        public DateTime? CancelationDate { get; set; }
        public double TotalPrice { get; set; }
        public double PaidPrice { get; set; }
        public string? StatusTitle { get; set; }
        public List<OrderDetail>? OrderDetails { get; set; }
    }

    public class OrderDetail
    {
        //public long Count { get; set; }
        public string? Title { get; set; }
        public double PaidPrice { get; set; }
        public double TotalPrice { get; set; }
        public long? ThumbnailId { get; set; }
        //public string? ProductTitle { get; set; }
    }
}
