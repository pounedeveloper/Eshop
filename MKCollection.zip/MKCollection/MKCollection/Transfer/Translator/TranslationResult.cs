﻿namespace MKCollection.Transfer.Translator
{
    public class TranslationResult
    {
        public bool IsNewTranslation { get; set; }
        public long TranslationId { get; set; }
        public string? TranslatedText { get; set; }
    }
}
