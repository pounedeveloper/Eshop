﻿namespace MKCollection.Transfer.Translator
{
    public class TranslatParams
    {
        public string Key { get; set; }
        public string Language { get; set; }
    }
}
