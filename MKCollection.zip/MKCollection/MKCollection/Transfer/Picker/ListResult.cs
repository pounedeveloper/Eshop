﻿using System.Collections;

namespace MKCollection.Transfer.Picker
{
    public class ListResult
    {
        public IEnumerable Result { get; set; }

    }
}
