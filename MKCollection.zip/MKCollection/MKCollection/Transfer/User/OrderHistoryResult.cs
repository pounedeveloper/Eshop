﻿using MKCollection.Models;

namespace MKCollection.Transfer.User
{
    public class OrderHistoryResult
    {
        public long Id { get; set; }
        public DateTime Date { get; set; }
        public double PaidPrice { get; set; }
        public double TotalPrice { get; set; }
        public string Code { get; set; } = null!;
        public DateTime? CancelationDate { get; set; }
        public List<InvoiceDetailResult> InvoiceDetails { get; set; }=new List<InvoiceDetailResult>();

    }

    public class InvoiceDetailResult
    {
        public int Count { get; set; }
        public double PaidPrice { get; set; }

        public long? ProductId { get; set; }
        public string? ProductTitle { get; set; }
        public long? ProductThumbnailId { get; set; }

        public long? ProductDetailId { get; set; }

    }
}
