﻿using MKCollection.Models;
using MKCollection.Services;
using System.Collections;

namespace MKCollection.DataPickers
{
    public class CollectionPicker : DataPickerOptions
    {
        protected override void SetupControl()
        {
            Fields = new[] { new FieldOptions { Caption = "عنوان ", DataField = "Title", Width = 180, SearchMode = SearchMode.ApplicationSearch } };
            DataTextField = "Title";
        }
        public override IEnumerable PrepareData()
        {

            return DataSource = ModelServiceBase<Collection>.GetSelectiveAsync(i => new { Id = i.Id.ToString(), Title = i.Title }, p => p.IsActive && p.InMenu).ToList();

        }
    }
}
