﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MKCollection.Applications;
using MKCollection.Models;
using MKCollection.Services;
using MKCollection.Transfer.Customer;
using SmsServiceReference;
using System.Reflection.Metadata.Ecma335;

namespace MKCollection.Controllers
{
    public sealed class CustomerController(CustomerApplication application) : ApplicationApiControllerBase<Customer>(application)
    {
        [HttpPost("CustomerInquery")]
        public async Task<ActionResult<Result<List<CustomerInqueryResult>>>> CustomerInquery([FromBody] CustomerInqueryParams parameters) =>
        ToActionResult(await ((CustomerApplication)Application).CustomerInquery(parameters));

        [HttpPost("ToggleCustomerActive")]
        public async Task<ActionResult<Result>> ToggleCustomerActive(long id) =>
        ToActionResult(await ((CustomerApplication)Application).ToggleCustomerActive(id));

        [HttpPost("ToggleCustomerListActive")]
        public async Task<ActionResult<Result>> ToggleCustomerListActive(List<long> ids) =>
        ToActionResult(await ((CustomerApplication)Application).ToggleCustomerListActive(ids));

        [HttpPost("CustomerDetails/{id}")]
        public async Task<ActionResult<Result<CustomerDetailsResult>>> CustomerDetails(long id) =>
        ToActionResult(await ((CustomerApplication)Application).CustomerDetails(id));

        [AllowAnonymous]
        [HttpPost("CustomerAuthenticate")]
        public async Task<ActionResult<Result<CustomerModel.LoginResult>>> CustomerAuthenticate(CustomerModel.LoginModel login) =>
        ToActionResult(await ((CustomerApplication)Application).CustomerAuthenticate(login));

        [AllowAnonymous]
        [HttpPost("CustomerRegister")]
        public async Task<ActionResult<Result>> CustomerRegister(CustomerModel.CustomerRegister register)
        {
            await Utilities.SendSms("09911850683", "کد شما: 123456");
            return ToActionResult(await ((CustomerApplication)Application).CustomerRegister(register));
        }

        [AllowAnonymous]
        [HttpPost("ForgetPassword")]
        public async Task<ActionResult<Result>> ForgetPassword(CustomerModel.LoginModel forgetModel) =>
        ToActionResult(await ((CustomerApplication)Application).ForgetPassword(forgetModel));

        [AllowAnonymous]
        [HttpPost("ResetPassword")]
        public async Task<ActionResult<Result>> ResetPassword(CustomerModel.ResetPasswordViewModel resetModel) =>
        ToActionResult(await ((CustomerApplication)Application).ResetPassword(resetModel));

        [AllowAnonymous]
        [HttpGet("GetCustomerByPhone")]
        public async Task<ActionResult<Result<CustomerByPhoneResult>>> GetCustomerByPhone(string phone) =>
        ToActionResult(await ((CustomerApplication)Application).GetCustomerByPhone(phone));
    }
}
