﻿using Microsoft.AspNetCore.Mvc;
using MKCollection.Applications;
using MKCollection.Models;
using MKCollection.Transfer.Customer;
using MKCollection.Transfer.CustomerAddress;

namespace MKCollection.Controllers
{
    public sealed class CustomerAddressController(CustomerAddressApplication application) : ApplicationApiControllerBase<CustomerAddress>(application)
    {

        [HttpPut("SubmitAddress")]
        public async Task<ActionResult<Result>> SubmitAddress([FromBody] SubmitAddressParams addressParams) =>
            ToActionResult(await ((CustomerAddressApplication)Application).SubmitAddress(addressParams, (long)(Convert.ToDouble(this.User.Identity.Name))));

        [HttpPut("DeleteAddress/{addressId}")]
        public async Task<ActionResult<Result>> DeleteAddress(long addressId) =>
            ToActionResult(await ((CustomerAddressApplication)Application).DeleteAddress(addressId));

        [HttpGet("CustomerAddresses/{customerId}")]
        public async Task<ActionResult<Result<List<CustomerAddressResult>>>> CustomerAddresses(long customerId) =>
            ToActionResult(await ((CustomerAddressApplication)Application).CustomerAddresses(customerId));
    }
}
