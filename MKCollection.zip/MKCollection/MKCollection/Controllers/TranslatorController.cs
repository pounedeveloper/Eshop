﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MKCollection.Applications;
using MKCollection.Filter;
using MKCollection.Models;
using MKCollection.Transfer.Category;
using MKCollection.Transfer.Translator;
using static System.Net.Mime.MediaTypeNames;

namespace MKCollection.Controllers
{
    
    public class TranslatorController(TranslatorApplication application) : ApplicationApiControllerBase<Translation>(application)
    {
        [HttpPost("Translate")]
        public async Task<ActionResult<Result<TranslationResult>>> Translate(TranslatParams translatParams) =>
        ToActionResult(await ((TranslatorApplication)Application).Translate(translatParams));
    }
}
