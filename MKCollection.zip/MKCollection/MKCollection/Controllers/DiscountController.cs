﻿using Microsoft.AspNetCore.Mvc;
using MKCollection.Applications;
using MKCollection.Models;
using MKCollection.Transfer.Discount;

namespace MKCollection.Controllers
{
    public class DiscountController(DiscountApplication application) : ApplicationApiControllerBase<Discount>(application)
    {
        [HttpPost("CreateDiscount")]
        public async Task<ActionResult<Result>> CreateDiscount([FromBody] CreateDiscountParams discountParams) =>
       ToActionResult(await ((DiscountApplication)Application).CreateDiscount(discountParams));

        [HttpPut("UpdateDiscount/{id:long}")]
        public async Task<ActionResult<Result>> UpdateDiscount(long id, [FromBody] UpdateDiscountParams discountParams) =>
       ToActionResult(await ((DiscountApplication)Application).UpdateDiscount(id, discountParams));

        [HttpPut("ToggleDiscountActive/{id:long}")]
        public async Task<ActionResult<Result>> ToggleDiscountActive(long id) =>
       ToActionResult(await ((DiscountApplication)Application).ToggleDiscountActive(id));

        [HttpPost("DiscountInquery")]
        public async Task<ActionResult<Result<List<DiscountInqueryResult>>>> DiscountInquery(DiscountInqueryParams parameters) =>
        ToActionResult(await ((DiscountApplication)Application).DiscountInquery(parameters));



    }
}
