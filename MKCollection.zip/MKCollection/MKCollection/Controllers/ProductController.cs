﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MKCollection.Applications;
using MKCollection.Models;
using MKCollection.Transfer.Product;

namespace MKCollection.Controllers
{
    public sealed class ProductController(ProductApplication application) : ApplicationApiControllerBase<Product>(application)
    {
        [HttpPut("ToggleProductActive/{id}")]
        public async Task<ActionResult<Result>> ToggleProductActive(long id, long status) =>
        ToActionResult(await ((ProductApplication)Application).ToggleProductActive(id, status));

        [AllowAnonymous]
        [HttpGet("GetByCategory")]
        public async Task<ActionResult<Result<List<ByCategoryResult>>>> GetByCategory(long categoryId) =>
        ToActionResult(await ((ProductApplication)Application).GetByCategory(categoryId));

        [HttpPost("CreateProduct")]
        public async Task<ActionResult<Result>> CreateProduct([FromBody] CreateProductParams productParams) =>
         ToActionResult(await ((ProductApplication)Application).CreateProduct(productParams));

        [AllowAnonymous]
        [HttpPost("ProductInquery")]
        public async Task<ActionResult<Result<List<ProductInqueryResult>>>> ProductInquery(ProductInqueryParams parameters) =>
        ToActionResult(await ((ProductApplication)Application).ProductInquery(parameters));

        [AllowAnonymous]
        [HttpPut("ToggleProductActive")]
        public async Task<ActionResult<Result>> ToggleProductActive([FromBody] List<long> ids, long status) =>
        ToActionResult(await ((ProductApplication)Application).ToggleProductListActive(ids, status));

        [AllowAnonymous]
        [HttpPut("GetProductById/{id}")]
        public async Task<ActionResult<Result<ProductResult>>> GetProductById(long id) =>
        ToActionResult(await ((ProductApplication)Application).GetProductById(id));

        [HttpPut("NewProducts/{limit}")]
        public async Task<ActionResult<Result<List<NewProductsResult>>>> NewProducts(int limit) =>
        ToActionResult(await ((ProductApplication)Application).NewProducts(limit));

        [HttpPost("CreateProductsByExcel")]
        public bool CreateProductsByExcel(IFormFile file) =>
       ((ProductApplication)Application).CreateProductsByExcel(file);
    }
}
