﻿using Microsoft.AspNetCore.Mvc;
using MKCollection.Applications;
using MKCollection.Transfer.Picker;

namespace MKCollection.Controllers
{
    public class PickerController(PickerApplication application) : ApiControllerBase()
    {
        public PickerApplication Application { get; } = application;

        [HttpGet("Options")]
        public ActionResult<Result<OptionsResult>> Options(string picker) =>
             ToActionResult(((PickerApplication)Application).Options(picker));

        [HttpGet("List")]
        public ActionResult<Result<ListResult>> List(string picker, string? condition, string? key, string? parentField) =>
            ToActionResult(((PickerApplication)Application).List(picker, condition, key, parentField));
    }
}
