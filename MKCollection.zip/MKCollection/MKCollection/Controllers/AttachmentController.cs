﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MKCollection.Applications;
using MKCollection.Models;
using MKCollection.Transfer.Attachment;

namespace MKCollection.Controllers
{
    public sealed class AttachmentController(AttachmentApplication application) : ApplicationApiControllerBase<Attachment>(application)
    {
        [AllowAnonymous]
        [HttpGet("Render/{id}")]
        public async Task<Result<RenderAttachmentResult>> Render(long id)
        {
            Result<RenderAttachmentResult> renderResult = await ((AttachmentApplication)Application).Render(id);
            if (renderResult.IsFailed)
            {
                return new Result<RenderAttachmentResult>() { Data = null, Error = "not found", IsSuccess = false };
            }

            return renderResult;
        }

        [AllowAnonymous]
        [HttpGet("Thumbnail/{id}")]
        public async Task<IActionResult> Thumbnail(long id)
        {
            Result<RenderAttachmentResult> renderResult = await ((AttachmentApplication)Application).Thumbnail(id);
            if (renderResult.IsFailed)
            {
                return NotFound();
            }

            RenderAttachmentResult result = renderResult.Data!;
            return File(result.Data, result.ContentType, result.Name);
        }

        [HttpPost("Create")]
        public async Task<ActionResult<Result<long>>> Create(AttachmentParam attachmentParam) =>
             ToActionResult(await ((AttachmentApplication)Application).CreateAttachmentAsync(attachmentParam));
    }
}
