﻿using MKCollection.Applications;



namespace MKCollection.Controllers;

public abstract class ApplicationApiControllerBase<TModel>(ApplicationBase<TModel> application) : ApiControllerBase where TModel : class
{
    protected ApplicationBase<TModel> Application { get; init; } = application;


}