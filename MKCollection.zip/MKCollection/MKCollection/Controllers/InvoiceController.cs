﻿using MKCollection.Models;
using Microsoft.AspNetCore.Mvc;
using MKCollection.Applications;
using MKCollection.Transfer.Invoice;


namespace MKCollection.Controllers
{
    public sealed class InvoiceController(InvoiceApplication application) : ApplicationApiControllerBase<Invoice>(application)
    {
        [HttpPost("InvoiceInquery")]
        public async Task<ActionResult<Result<List<InvoiceInqueryResult>>>> InvoiceInquery([FromBody] InvoiceInqueryParams parameters) =>
            ToActionResult(await ((InvoiceApplication)Application).InvoiceInquery(parameters));

        [HttpPost("CancelCart/{id}")]
        public async Task<ActionResult<Result>> CancelCart(long id) =>
            ToActionResult(await ((InvoiceApplication)Application).CancelCart(id));

        [HttpPost("AddToCart")]
        public async Task<ActionResult<Result>> AddToCart([FromBody] AddToCartParams parameters) => 
            ToActionResult(await ((InvoiceApplication)Application).AddToCart(parameters, (long)(Convert.ToDouble(this.User.Identity.Name))));
    }
}
