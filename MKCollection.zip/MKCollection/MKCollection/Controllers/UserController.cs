﻿using MKCollection.Models;
using Microsoft.AspNetCore.Mvc;
using MKCollection.Applications;
using MKCollection.Transfer.User;
namespace MKCollection.Controllers;


    public sealed class UserController(UserApplication application) : ApplicationApiControllerBase<User>(application)
    {
    [HttpPost("OrderHistory")]
    public async Task<ActionResult<Result<List<OrderHistoryResult>>>> OrderHistory() =>
    ToActionResult(await ((UserApplication)Application).OrderHistory());
}

