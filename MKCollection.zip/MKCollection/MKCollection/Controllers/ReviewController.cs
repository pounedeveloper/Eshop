﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MKCollection.Applications;
using MKCollection.Models;
using MKCollection.Services;
using MKCollection.Transfer;
using MKCollection.Transfer.Product;
using MKCollection.Transfer.Review;
using System.IdentityModel.Tokens.Jwt;

namespace MKCollection.Controllers
{
    public class ReviewController(ReviewApplication application) : ApplicationApiControllerBase<Review>(application)
    {
        [HttpPut("SubmitReview")]
        public async Task<ActionResult<Result>> SubmitReview([FromBody] SubmitReviewParams item) => 
        ToActionResult(await ((ReviewApplication)Application).SubmitReview(item, (long)Convert.ToDouble(this.User.Identity.Name)));

        [HttpGet("GetCustomerProductReview/{productId:long}")]
        public async Task<ActionResult<Result<CustomerProductResult>>> GetCustomerProductReview(long productId) =>
        ToActionResult(await ((ReviewApplication)Application).GetCustomerProductReview(productId));

        [HttpDelete("DeleteReview/{id:long}")]
        public async Task<ActionResult<Result>> DeleteReview(long id) =>
        ToActionResult(await ((ReviewApplication)Application).DeleteReview(id));

        [HttpGet("GetReviewById/{id:long}")]
        public async Task<ActionResult<Result<ReviewByIdResult>>> GetReviewById(long id) =>
        ToActionResult(await ((ReviewApplication)Application).GetReviewById(id));
        [AllowAnonymous]
        [HttpPut("GetReviewsByProduct/{productId:long}")]
        public async Task<Result<ReviewsByProductResult>> GetReviewsByProduct(long productId, Paginated parameters) =>
        await ((ReviewApplication)Application).GetReviewsByProduct(productId, parameters);
    }
}
