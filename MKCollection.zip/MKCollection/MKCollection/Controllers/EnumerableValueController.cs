﻿using Microsoft.AspNetCore.Mvc;
using MKCollection.Applications;
using MKCollection.Models;
using MKCollection.Transfer.EnumerableValue;

namespace MKCollection.Controllers
{
    public class EnumerableValueController(EnumerableValueApplication application) : ApplicationApiControllerBase<EnumerableValue>(application)
    {
        [HttpGet("GetEnumValueByEnumId/{enumId}")]
        public async Task<ActionResult<Result<List<EnumValueByEnumIdResult>>>> GetEnumValueByEnumId(long enumId) =>
            ToActionResult(await ((EnumerableValueApplication)Application).GetEnumValueByEnumId(enumId));

        [HttpGet("ToggleEnumValueActive/{id}")]
        public async Task<ActionResult<Result>> ToggleEnumValueActive(long id) =>
            ToActionResult(await ((EnumerableValueApplication)Application).ToggleEnumValueActive(id));

        [HttpPost("InsertEnumValue")]
        public async Task<ActionResult<Result>> InsertEnumValue([FromBody] InsertEnumValueParams item) =>
            ToActionResult(await ((EnumerableValueApplication)Application).InsertEnumValue(item));
    }
}
