﻿using Microsoft.AspNetCore.Mvc;
using MKCollection.Applications;

namespace MKCollection.Controllers;

[ApiController]
[Route("[controller]")]
public abstract class ApiControllerBase : ControllerBase
{
    protected ActionResult<Result<T>> ToActionResult<T>(Result<T> result) =>
         result.IsSuccess ? Ok(result) : BadRequest(result);
    protected ActionResult<Result> ToActionResult(Result result) =>
         result.IsSuccess ? Ok(result) : BadRequest(result);
}
