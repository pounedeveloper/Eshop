﻿using Microsoft.AspNetCore.Mvc;
using MKCollection.Applications;
using MKCollection.Models;
using MKCollection.Transfer.Category;


namespace MKCollection.Controllers;

public sealed class CategoryController(CategoryApplication application) : ApplicationApiControllerBase<Category>(application)
{
    [HttpPost("CategoryInquery")]
    public async Task<ActionResult<Result<List<CategoryInqueryResult>>>> CategoryInquery(CategoryInqueryParams parameters) =>
        ToActionResult(await ((CategoryApplication)Application).CategoryInquery(parameters));

    [HttpPut("RemoveProductCategory/{productId}/{categoryId}")]
    public async Task<ActionResult<Result>> RemoveProductCategory(long productId, long categoryId) =>
    ToActionResult(await ((CategoryApplication)Application).RemoveProductCategory(productId, categoryId));

    [HttpPut("AddProductCategory/{productId}/{categoryId}")]
    public async Task<ActionResult<Result>> AddProductCategory(long productId, long categoryId) =>
    ToActionResult(await ((CategoryApplication)Application).AddProductCategory(productId, categoryId));

    [HttpPut("UpsertCategory")]
    public async Task<ActionResult<Result>> UpsertCategory([FromBody] UpsertCategoryParams categoryParams) =>
    ToActionResult(await ((CategoryApplication)Application).UpsertCategory(categoryParams));

    [HttpGet("GetCategoryById/{id:long}")]
    public async Task<ActionResult<Result<GetCategoryByIdResult>>> GetCategoryById(long id) =>
    ToActionResult(await ((CategoryApplication)Application).GetCategoryById(id));

    [HttpPut("DeleteCategory/{id:long}")]
    public async Task<ActionResult<Result>> DeleteCategory(long id) =>
    ToActionResult(await ((CategoryApplication)Application).DeleteCategory(id));
}


