﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using MKCollection.Applications;
using MKCollection.Models;
using MKCollection.Transfer.Collectio;


namespace MKCollection.Controllers;

public sealed class CollectionController(CollectionApplication application) : ApplicationApiControllerBase<Collection>(application)
{
    [AllowAnonymous]
    [HttpPost("CollectionInquery")]
    public async Task<ActionResult<Result<List<CollectionInqueryResult>>>> CollectionInquery(CollectionInqueryParams parameters) =>
        ToActionResult(await ((CollectionApplication)Application).CollectionInquery(parameters));

    [HttpPut("RemoveProductCollection/{productId}/{collectionId}")]
    public async Task<ActionResult<Result>> RemoveProductCollection(long productId, long collectionId) =>
        ToActionResult(await ((CollectionApplication)Application).RemoveProductCollection(productId, collectionId));

    [HttpPut("AddProductCollection/{productId}/{collectionId}")]
    public async Task<ActionResult<Result>> AddProductCollection(long productId, long collectionId) =>
        ToActionResult(await ((CollectionApplication)Application).AddProductCollection(productId, collectionId));

    [HttpPut("UpsertCollection")]
    public async Task<ActionResult<Result>> UpsertCollection([FromBody] UpsertCollectionParams collectionParams) =>
        ToActionResult(await ((CollectionApplication)Application).UpsertCollection(collectionParams));
    [AllowAnonymous]
    [HttpGet("GetCollectionById/{id:long}")]
    public async Task<ActionResult<Result<GetCollectionByIdResult>>> GetCollectionById(long id) =>
        ToActionResult(await ((CollectionApplication)Application).GetCollectionById(id));

    [HttpDelete("DeleteCollection/{id:long}")]
    public async Task<ActionResult<Result>> DeleteCollection(long id) =>
        ToActionResult(await ((CollectionApplication)Application).DeleteCollection(id));
}


