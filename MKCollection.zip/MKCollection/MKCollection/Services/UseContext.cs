﻿namespace MKCollection.Services
{
    public class UseContext
    {
        private readonly IHttpContextAccessor _httpContextAccessor;
        public UseContext(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }
        public string? GetTokenHeader()
        {
            var accessToken = _httpContextAccessor.HttpContext?.Request.Headers["Authorization"];
            if (!string.IsNullOrEmpty(accessToken))
            {
                var token = accessToken.ToString().Replace("Bearer ", "");
                return token;
            }
            return null;
        }
        public string GetUserIp()
        {
            var ip = _httpContextAccessor.HttpContext.Connection.RemoteIpAddress;
            return ip.ToString();
        }
        public string GetUserUrl()
        {
            var url = _httpContextAccessor.HttpContext.Request.Host.Value;
            return url;
        }

        public long? GetUserId()
        {
            string? token = GetTokenHeader();
            if (!string.IsNullOrEmpty(token))
            {
                return TokenManager.GetTokenUserId(token).ChangeType<long>();
            }
            return null;
        }

        public string MapImagePath(string id)
        {
            string imagePath = Path.Combine(_httpContextAccessor.HttpContext.Request.Path, "images", "1536", id + ".jpeg");
            return imagePath;
        }
    }
}
