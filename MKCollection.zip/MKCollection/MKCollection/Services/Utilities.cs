﻿using System.Security.Cryptography;
using System.Text;
using System.Xml;
using System.Xml.Serialization;
using SmsServiceReference;
using System.Data;
using System.Data.SqlClient;
using System.ServiceModel;
using static SmsServiceReference.BoxServiceSoapClient;
using MKCollection.Models;
using System.Security.Claims;

namespace MKCollection.Services
{
    public static class Utilities
    {
        public static void LogException(Exception exception)
        {
            string exceptionData = string.Empty;
            while (exception != null)
            {
                exceptionData += string.Format("{0}{1}{2}{1}======================================================={1}",
                    exception.Message,
                    Environment.NewLine,
                exception.StackTrace
                    );
                exception = exception.InnerException;
            }
            MkcollectionContext mkcollection = new MkcollectionContext();
            mkcollection.Add(new ExceptionLog { UserName = new UseContext(new HttpContextAccessor()).GetUserId().ToString(), LogTime = DateTime.Now, ClientIp = new UseContext(new HttpContextAccessor()).GetUserIp(), ExceptionData = exceptionData, RequestUrl = new UseContext(new HttpContextAccessor()).GetUserUrl() });
            mkcollection.SaveChanges();
        }
        public static string SerializeToString<T>(T instance)
        {
            using (var stream = new System.IO.MemoryStream())
            using (var xmlWriter = new XmlTextWriter(stream, Encoding.UTF8))
            {
                var serializer = new XmlSerializer(typeof(T));
                serializer.Serialize(xmlWriter, instance);
                return Encoding.UTF8.GetString(stream.GetBuffer());
            }
        }

        public static string ComputeHash(string encryptionValue)
        {
            MD5 encryptor = new MD5CryptoServiceProvider();
            return Convert.ToBase64String(encryptor.ComputeHash(Encoding.Unicode.GetBytes(encryptionValue)));
        }

        public static async Task<bool> SendSms(string mobileNo, string textMessage)
        {
            try
            {
                var a = new EndpointConfiguration();
                var endpoint = new EndpointAddress("http://www.afe.ir/WebService/V7/BoxService.asmx");
                ArrayOfString mobileNoList = new ArrayOfString();
                mobileNoList.Add(mobileNo);
                SendMessageRequestBody request = new SendMessageRequestBody { Message = textMessage, Mobile = mobileNoList, Username = "info@adriansystem.com", Password = "29e9d3c2", Number = "30007957954520", Type = "1" };
                var send = new SendMessageRequest(request);
                using (var client = new BoxServiceSoapClient(a))
                {
                    SendMessageResponse res = await client.SendMessageAsync("info@adriansystem.com", "29e9d3c2", "30007957954520", mobileNoList, textMessage, "1");
                    return true;
                };
            }
            catch (Exception)
            {
                return false;
            }
        }
        public static string GetUniqueNumberAsPerDate()
        {
            var random = new Random(DateTime.Now.Millisecond);
            var randomNumber = random.Next(0, 1000000);
            return randomNumber.ToString("D6");
        }
        public static string NumberToString(string snum)
        {
            string stotal = "";
            if (snum == "") return "صفر";
            if (snum == "0")
                return yakan[0];
            snum = snum.PadLeft(((snum.Length - 1) / 3 + 1) * 3, '0');
            int L = snum.Length / 3 - 1;
            for (int i = 0; i <= L; i++)
            {
                int b = int.Parse(snum.Substring(i * 3, 3));
                if (b != 0)
                    stotal = stotal + getnum3(b) + " " + basex[L - i] + " و ";
            }
            stotal = stotal.Substring(0, stotal.Length - 3);
            return stotal;
        }
        public static bool IsValidNationalCode(string nationalCode)
        {
            if (string.IsNullOrEmpty(nationalCode))
                return false;
            if (nationalCode.Length < 10)
                return false;
            if (nationalCode.StartsWith("F"))
                return true;
            var allDigitEqual = new[] { "0000000000", "1111111111", "2222222222", "3333333333", "4444444444", "5555555555", "6666666666", "7777777777", "8888888888", "9999999999" };
            if (allDigitEqual.Contains(nationalCode)) return false;


            var chArray = nationalCode.ToCharArray();
            var num0 = Convert.ToInt32(chArray[0].ToString()) * 10;
            var num2 = Convert.ToInt32(chArray[1].ToString()) * 9;
            var num3 = Convert.ToInt32(chArray[2].ToString()) * 8;
            var num4 = Convert.ToInt32(chArray[3].ToString()) * 7;
            var num5 = Convert.ToInt32(chArray[4].ToString()) * 6;
            var num6 = Convert.ToInt32(chArray[5].ToString()) * 5;
            var num7 = Convert.ToInt32(chArray[6].ToString()) * 4;
            var num8 = Convert.ToInt32(chArray[7].ToString()) * 3;
            var num9 = Convert.ToInt32(chArray[8].ToString()) * 2;
            var a = Convert.ToInt32(chArray[9].ToString());

            var b = (((((((num0 + num2) + num3) + num4) + num5) + num6) + num7) + num8) + num9;
            var c = b % 11;

            return (((c < 2) && (a == c)) || ((c >= 2) && ((11 - c) == a)));
        }
        private static string getnum3(int num3)
        {
            string s = "";
            int d12;
            d12 = num3 % 100;
            var d3 = num3 / 100;
            if (d3 != 0)
                s = sadgan[d3] + " و ";
            if ((d12 >= 10) && (d12 <= 19))
                return s + dahyek[d12 - 10];
            int d2 = d12 / 10;
            if (d2 != 0)
                s = s + dahgan[d2] + " و ";
            int d1 = d12 % 10;
            if (d1 != 0)
                s = s + yakan[d1] + " و ";
            return s.Substring(0, s.Length - 3);
        }
        private static string[] yakan = new string[10] { "صفر", "یک", "دو", "سه", "چهار", "پنج", "شش", "هفت", "هشت", "نه" };

        private static string[] dahgan = new string[10] { "", "", "بیست", "سی", "چهل", "پنجاه", "شصت", "هفتاد", "هشتاد", "نود" };

        private static string[] dahyek = new string[10] { "ده", "یازده", "دوازده", "سیزده", "چهارده", "پانزده", "شانزده", "هفده", "هجده", "نوزده" };

        private static string[] sadgan = new string[10] { "", "یکصد", "دویست", "سیصد", "چهارصد", "پانصد", "ششصد", "هفتصد", "هشتصد", "نهصد" };

        private static string[] basex = new string[5] { "", "هزار", "میلیون", "میلیارد", "تریلیون" };


        public static IList<DateTime> EachDay(DateTime from, DateTime thru)
        {
            var days = new List<DateTime>();
            for (var day = from.Date; day.Date <= thru.Date; day = day.AddDays(1))
                days.Add(day);
            return days;
        }
        public static double GetLotSum(string lenght)
        {
            var lenghtList = lenght.SplitCsv<double>("-");
            var sum = Math.Round(lenghtList.Sum(), 2);
            return sum;
        }
        public static string GenerateFileName()
        {
            string timestamp = DateTime.Now.ToString("yyyyMMddHHmmssfff");
            string randomString = Path.GetRandomFileName().Replace(".", "").Substring(0, 2);
            string fileName = $"{timestamp}_{randomString}";
            return fileName;
        }
    }
}