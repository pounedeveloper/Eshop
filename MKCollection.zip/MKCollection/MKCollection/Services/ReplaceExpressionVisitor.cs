﻿using System.Linq.Expressions;
using System.Diagnostics.CodeAnalysis;

namespace MKCollection.Services;

internal class ReplaceExpressionVisitor
   : ExpressionVisitor
{
    private readonly Expression _oldValue;
    private readonly Expression _newValue;

    public ReplaceExpressionVisitor(Expression oldValue, Expression newValue)
    {
        _oldValue = oldValue;
        _newValue = newValue;
    }

    [return: NotNullIfNotNull("node")]
    public override Expression? Visit(Expression? node) => node == _oldValue ? _newValue : base.Visit(node);
}