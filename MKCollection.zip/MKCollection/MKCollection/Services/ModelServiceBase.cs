﻿using Microsoft.EntityFrameworkCore;
using MKCollection.Models;
using System.Linq.Expressions;

namespace MKCollection.Services;

public class ModelServiceBase<TModel> where TModel : class
{
    private const int LIMIT = 10;
    private readonly MkcollectionContext _mkcollectionContext;
    public ModelServiceBase(MkcollectionContext mkcollectionContext)
    {
        _mkcollectionContext = mkcollectionContext;
    }
    public async Task<TModel?> GetAsync(long id) => await _mkcollectionContext.Set<TModel>().FindAsync(id);
    public async Task<List<TModel>> GetAsync(Expression<Func<TModel, bool>>? filter, int? limit = null, int? skip = null) =>
          await _mkcollectionContext.Set<TModel>().Where(filter ?? (_ => true)).Skip(skip ?? 0).Take(limit ?? LIMIT).ToListAsync();

    public async Task<TModel?> FindAsync(Expression<Func<TModel, bool>>? filter) =>
         await _mkcollectionContext.Set<TModel>().FindAsync(filter ?? (_ => true));

    public async Task<bool> AnyAsync(Expression<Func<TModel, bool>> filter) => await _mkcollectionContext.Set<TModel>().AnyAsync(filter);

    public static List<TResult> GetSelectiveAsync<TResult>(Func<TModel, TResult> selector, Expression<Func<TModel, bool>> predicate = null)
    {
        try
        {
            using (var entities = new MkcollectionContext())
            {
                IQueryable<TModel> result = entities.Set<TModel>();

                return (predicate == null ? result : result.Where(predicate)).Select(selector).ToList();
            }
        }
        catch
        {
            throw;
        }
    }

    public async Task<List<TResult>> GetSelectiveAsync<TResult>(Expression<Func<TModel, TResult>> selector, Expression<Func<TModel, bool>>? filter, int? limit = null, int? skip = null) =>
        await _mkcollectionContext.Set<TModel>().Where(filter ?? (_ => true)).Select(selector).Skip(skip ?? 0).Take(limit ?? LIMIT).ToListAsync();


    public async Task<List<TResult>> GetSelectiveAsync<TResult>(Expression<Func<TModel, TResult>> selector, Expression<Func<TModel, bool>>? filter, Expression<Func<TModel, object>> orderByDescending, int? limit = null, int? skip = null) =>
        await _mkcollectionContext.Set<TModel>().Where(filter ?? (_ => true)).OrderByDescending(orderByDescending).Select(selector).Skip(skip ?? 0).Take(limit ?? LIMIT).ToListAsync();


    public async Task<long> CreateAsync(TModel newModel)
    {
        _mkcollectionContext.Set<TModel>().Add(newModel);
        await _mkcollectionContext.SaveChangesAsync();
        return (long)newModel.GetProperty("Id")!;
    }

    public async Task<List<long>> CreateRangeAsync(IEnumerable<TModel> newModels)
    {
        _mkcollectionContext.Set<TModel>().AddRange(newModels);
        await _mkcollectionContext.SaveChangesAsync();
        return newModels.Select(e => (long)e.GetProperty("Id")!).ToList();
    }

    public async Task UpdateAsync(long id, TModel updatedModel)
    {
        var existingModel = await _mkcollectionContext.Set<TModel>().FindAsync(id);

        if (existingModel is not null)
        {
            _mkcollectionContext.Entry(existingModel).CurrentValues.SetValues(updatedModel);
            await _mkcollectionContext.SaveChangesAsync();
        }
    }

    public async Task RemoveAsync(long id)
    {
        var model = await _mkcollectionContext.Set<TModel>().FindAsync(id);

        if (model is not null)
        {
            _mkcollectionContext.Set<TModel>().Remove(model);
            await _mkcollectionContext.SaveChangesAsync();
        }
    }



}