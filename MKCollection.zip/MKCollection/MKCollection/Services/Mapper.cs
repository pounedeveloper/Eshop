﻿using System.Reflection;
using System.Collections;
using System.Runtime.Serialization;

namespace MKCollection.Services;

public static class Mapper
{
    public static TResult Map<TResult>(object source) where TResult : class, new()
    {
        TResult result = new();
        result = (TResult)MapObjects(source, result);
        return result;
    }
    public static TResult Map<TResult>(object source, TResult target)
    {
        if (source == null || target == null)
        {
            return target;
        }

        TResult result = (TResult)MapObjects(source, target);
        return result;
    }
    public static object Map(object source, Type targetType)
    {
        object? result = CreateInstance(targetType);
        if (result == null)
        {
            throw new System.Exception();
        }

        result = MapObjects(source, result);
        return result;
    }

    public static TTarget Map<TSource, TTarget>(IEnumerable<TSource> sources, Type targetType)
    {
        IEnumerable result = MapCollection(sources, typeof(TSource), targetType);
        return MakeGenericCollection<TTarget>(result) ?? throw new WrongUsageException();
    }
    public static IEnumerable Map<TSource>(IEnumerable<TSource> sources, Type targetType)
    {
        IEnumerable result = MapCollection(sources, typeof(TSource), targetType);
        return result;
    }
    public static IEnumerable<TTarget?> Map<TSource, TTarget>(IEnumerable<TSource> sources)
    {
        IEnumerable<TTarget?> result = MapCollection(sources, typeof(TSource), typeof(TTarget)).Cast<TTarget>();
        return result;
    }

    private static IEnumerable MapCollection(IEnumerable sources, Type sourceType, Type targetType)
    {
        Dictionary<PropertyInfo, PropertyInfo> propertiyMap = GetPropertyMap(sourceType, targetType);
        foreach (object source in sources)
        {
            if (source == null)
            {
                yield return default;
            }
            else
            {
                object target = CreateInstance(targetType) ?? throw new WrongUsageException();
                yield return MapProperties(source, target, propertiyMap);
            }
        }
    }

    private static object MapObjects(object source, object target)
    {
        Dictionary<PropertyInfo, PropertyInfo> propertiyMap = GetPropertyMap(source.GetType(), target.GetType());
        return MapProperties(source, target, propertiyMap);
    }

    private static object MapProperties(object source, object target, Dictionary<PropertyInfo, PropertyInfo> propertiyMap)
    {
        _ = propertiyMap.ForEach(p =>
        {
            try
            {
                object? value = p.Key.GetValue(source);
                p.Value.SetValue(target, value);
            }
            catch
            {
            }
        });
        return target;
    }

    private static Dictionary<PropertyInfo, PropertyInfo> GetPropertyMap(Type sourceType, Type targetType)
    {
        IEnumerable<(PropertyInfo Property, MappingAttributeBase[] Attributes)> sourceProperties = sourceType.GetProperties().Select(p => (p, p.GetCustomAttributes<MappingAttributeBase>().ToArray()));
        IEnumerable<(PropertyInfo Property, MappingAttributeBase[] Attributes)> targetProperties = targetType.GetProperties().Select(p => (p, p.GetCustomAttributes<MappingAttributeBase>().ToArray()));
        Dictionary<PropertyInfo, PropertyInfo> propertiyMap = [];
        _ = sourceProperties.ForEach(sp =>
        {
            string sourceName = sp.Property.Name;
            MappingPairAttribute? mapTarget = sp.Attributes.OfType<MappingPairAttribute>().FirstOrDefault(a => a.MappingPair.ClassName == targetType.Name);
            mapTarget ??= sp.Attributes.OfType<MappingPairAttribute>().FirstOrDefault(a => a.MappingPair.ClassName == null);
            if (mapTarget != null)
            {
                sourceName = mapTarget.MappingPair.PropertyName;
            }

            if (targetProperties.FirstOrDefault(t => t.Property.Name == sourceName) is { } and { Property: { } } tp)
            {
                if (sp.Attributes.Any(a => a is MappingIgnoreAttribute) || tp.Attributes.Any(a => a is MappingIgnoreAttribute))
                {
                    return;
                }

                propertiyMap.Add(sp.Property, tp.Property);
            }
        });
        return propertiyMap;
    }

    private static T MakeGenericCollection<T>(object collection)
    {
        Type itemType = typeof(T).GetGenericArguments()[0];
        Type listType = typeof(List<>);
        Type constructedListType = listType.MakeGenericType(itemType);
        object list = CreateInstance(constructedListType) ?? throw new WrongUsageException();
        MethodInfo? method = list.GetType().GetMethod("Add") ?? throw new WrongUsageException();
        foreach (object item in (IEnumerable)collection)
        {
            _ = method.Invoke(list, new object[] { item });
        }

        return (T)list;
    }

    private static object? CreateInstance(Type type) => type.GetConstructor(Type.EmptyTypes) is { } ? Activator.CreateInstance(type) : FormatterServices.GetUninitializedObject(type);
}

[Serializable]
internal class WrongUsageException : Exception
{
    public WrongUsageException()
    {
    }

    public WrongUsageException(string? message) : base(message)
    {
    }

    public WrongUsageException(string? message, Exception? innerException) : base(message, innerException)
    {
    }
}

[AttributeUsage(AttributeTargets.Property, Inherited = false, AllowMultiple = true)]
public abstract class MappingAttributeBase : Attribute
{

}

[AttributeUsage(AttributeTargets.Property, Inherited = false, AllowMultiple = true)]
public class MappingPairAttribute : MappingAttributeBase
{
    public MappingPairAttribute(string className, string propertyName) => MappingPair = (className, propertyName);

    public MappingPairAttribute(string propertyName) => MappingPair = (null, propertyName);

    public (string? ClassName, string PropertyName) MappingPair { get; set; }
}

public class MappingIgnoreAttribute : MappingAttributeBase
{
}