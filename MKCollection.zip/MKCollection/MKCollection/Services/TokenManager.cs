﻿using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace MKCollection.Services
{
    public class TokenManager
    {
        const string security = "5TzGYeBgtl4C0YtN03uvFcV3BZ9qN5XjYZRmfdrwPjY=";
        private static readonly byte[] key = Convert.FromBase64String(security);
        public static string CreateToken(string username, string customerId)
        {
            var signingCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
        new Claim(ClaimTypes.Name, username),
        new Claim(ClaimTypes.PrimarySid, customerId)
    };

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(claims),
                Expires = DateTime.UtcNow.AddDays(1),
                Issuer = "http://localhost:3000",
                Audience = "http://localhost:3000",
                SigningCredentials = signingCredentials
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }

        public static string? GetTokenUserName(string? token)
        {
            var handler = new JwtSecurityTokenHandler();
            if (string.IsNullOrEmpty(token)) return null;

            var tokenRead = handler.ReadToken(token) as JwtSecurityToken;
            return tokenRead?.Claims.FirstOrDefault(x => x.Type == ClaimTypes.Name)?.Value;
        }

        public static string? GetTokenUserId(string? token)
        {
            var handler = new JwtSecurityTokenHandler();
            if (string.IsNullOrEmpty(token)) return null;

            var tokenRead = handler.ReadToken(token) as JwtSecurityToken;
            return tokenRead?.Claims.FirstOrDefault(x => x.Type == ClaimTypes.PrimarySid)?.Value;
        }

        public string ValidateJwtToken(string token)
        {
            var tokenHandler = new JwtSecurityTokenHandler();

            try
            {
                tokenHandler.ValidateToken(token, new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ValidateIssuer = true,
                    ValidIssuer = "http://localhost:3000",
                    ValidateAudience = true,
                    ValidAudience = "http://localhost:3000",
                    ClockSkew = TimeSpan.Zero
                }, out SecurityToken validatedToken);

                var jwtToken = (JwtSecurityToken)validatedToken;
                var name = jwtToken.Claims.First(x => x.Type == ClaimTypes.Name).Value;
                return name;
            }
            catch
            {
                return null;
            }
        }
    }
}
