﻿using System.Linq.Expressions;
using System.Reflection;

namespace MKCollection.Services;

public static class Extentions
{
    public static Expression<Func<T, bool>>? And<T>(this Expression<Func<T, bool>>? expr1, Expression<Func<T, bool>>? expr2) => AppendCondition(expr1, expr2, false);
    public static Expression<Func<T, bool>>? AndIf<T>(this Expression<Func<T, bool>>? expr1, Expression<Func<T, bool>>? expr2, bool condition) => condition ? AppendCondition(expr1, expr2, false) : expr1;
    public static Expression<Func<T, bool>>? Or<T>(this Expression<Func<T, bool>>? expr1, Expression<Func<T, bool>>? expr2) => AppendCondition(expr1, expr2, true);
    public static Expression<Func<T, bool>>? OrIf<T>(this Expression<Func<T, bool>>? expr1, Expression<Func<T, bool>>? expr2, bool condition) => condition ? AppendCondition(expr1, expr2, true) : expr1;

    public static Expression<Func<T, bool>>? AppendCondition<T>(this Expression<Func<T, bool>>? expr1, Expression<Func<T, bool>>? expr2, bool isOrType = true)
    {
        if (expr1 == null)
        {
            return expr2;
        }

        if (expr2 == null)
        {
            return expr1;
        }

        ParameterExpression parameter = Expression.Parameter(typeof(T));
        ReplaceExpressionVisitor leftVisitor = new(expr1.Parameters[0], parameter);
        Expression left = leftVisitor.Visit(expr1.Body);
        ReplaceExpressionVisitor rightVisitor = new(expr2.Parameters[0], parameter);
        Expression right = rightVisitor.Visit(expr2.Body);
        return isOrType ? Expression.Lambda<Func<T, bool>>(Expression.OrElse(left, right), parameter) : Expression.Lambda<Func<T, bool>>(Expression.AndAlso(left, right), parameter);
    }

    public static Func<T, bool> AppendCondition<T>(this Func<T, bool> condition1, Func<T, bool> condition2, bool isOrType = true)
    {
        if (condition1 == null)
            return condition2;
        if (condition2 == null)
            return condition1;
        if (isOrType)
            return i => condition1(i) || condition2(i);
        return i => condition1(i) && condition2(i);
    }

    public static IEnumerable<T> ForEach<T>(this IEnumerable<T> source, Action<T> action)
    {
        if (source == null)
        {
            return Enumerable.Empty<T>();
        }

        IEnumerator<T> enumerator = source.GetEnumerator();
        while (enumerator.MoveNext())
        {
            action(enumerator.Current);
        }

        return source;
    }

    public static object? GetProperty(this object instance, string propertyName)
    {
        var propertyInfo = instance.GetType().GetProperty(propertyName, BindingFlags.Public | BindingFlags.Instance);
        return propertyInfo?.GetValue(instance, null);
    }

    public static string JoinCsv<T>(this IEnumerable<T> source, string separator = ",")
    {
        if (source == null || !source.Any())
            return string.Empty;
        return string.Join(separator, source.Select(i => i!.ToString()));
    }
    public static IEnumerable<T> SplitCsv<T>(this string source, string seperator = ",")
    {
        if (string.IsNullOrEmpty(source))
            return System.Linq.Enumerable.Empty<T>();
        return source.Split(new[] { seperator }, StringSplitOptions.RemoveEmptyEntries).Select(i => (T)i.ChangeType(typeof(T)));
    }
    public static T ChangeType<T>(this object value)
    {
        return (T)ChangeType(value, typeof(T));
    }

    public static object ChangeType(this object value, Type type)
    {
        if (((type.IsGenericType && type.GetGenericTypeDefinition() == typeof(Nullable<>)) || typeof(string) == type) && value == null)
            return null;
        if (value.GetType() == type)
            return value;
        type = Nullable.GetUnderlyingType(type) ?? type;
        if (type == typeof(DateTime) && value.GetType() == typeof(string))
            value = ((string)value).Replace("ق.ظ", "AM").Replace("ب.ظ", "PM");
        return (value == null || (value is string && String.IsNullOrEmpty(value as string))) ? null : Convert.ChangeType(value, type);
    }
}