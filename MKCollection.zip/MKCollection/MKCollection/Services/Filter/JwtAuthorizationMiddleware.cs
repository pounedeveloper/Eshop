﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.Net.Http.Headers;
using MKCollection.Models;
using MKCollection.Services;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

public sealed class JwtAuthorizationMiddleware
{
    private static readonly string Bearer = "bearer";
    private readonly JwtSecurityTokenHandler _handler = new JwtSecurityTokenHandler();
    private readonly RequestDelegate _next;

    public JwtAuthorizationMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task Invoke(HttpContext context)
    {
        try
        {
            if (context.Request.Path.StartsWithSegments("/swagger"))
            {
                await _next(context);
                return;
            }
            var endpoint = context.GetEndpoint();
            if (endpoint?.Metadata?.GetMetadata<AllowAnonymousAttribute>() != null)
            {
                await _next(context);
                return;
            }
            var token = context.Request.Headers[HeaderNames.Authorization].ToString();
            if (!token.ToLower().StartsWith(Bearer))
            {
                context.Response.StatusCode = StatusCodes.Status401Unauthorized;
                await context.Response.WriteAsync("Unauthorized: Invalid or expired token");
                return;
            }

            var jwt = _handler.ReadJwtToken(token.Substring(Bearer.Length).TrimStart());
            context.User = new ClaimsPrincipal(new ClaimsIdentity(jwt.Claims));

            await _next(context);

        }
        catch (Exception ex)
        {
            context.Response.StatusCode = StatusCodes.Status401Unauthorized;
            await context.Response.WriteAsync("Unauthorized: Invalid or expired token");
            return;
        }
    }
}