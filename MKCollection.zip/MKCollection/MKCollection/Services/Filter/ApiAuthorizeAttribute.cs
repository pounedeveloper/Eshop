﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using MKCollection.Services;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication.JwtBearer;

namespace MKCollection.Filter
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method)]
    public class ApiAuthorizeAttribute : Attribute, IAuthorizationFilter
    {
        private readonly JwtBearerOptions _jwtBearerOptions;

        public ApiAuthorizeAttribute(IOptions<JwtBearerOptions> jwtBearerOptions)
        {
            _jwtBearerOptions = jwtBearerOptions.Value;
        }

        public void OnAuthorization(AuthorizationFilterContext context)
        {
            if (AuthorizeAsync(context).GetAwaiter().GetResult())
            {
                return;
            }
            else
            {
                HandleUnauthorizedRequest(context);
            }
        }

        protected void HandleUnauthorizedRequest(AuthorizationFilterContext context)
        {
            if (context == null)
                throw new ArgumentNullException(nameof(context), "Context cannot be null");

            context.Result = new JsonResult(new
            {
                message = "Unauthorized",
                StatusCode = StatusCodes.Status401Unauthorized
            })
            {
                StatusCode = StatusCodes.Status401Unauthorized
            };
        }

        private async Task<bool> AuthorizeAsync(AuthorizationFilterContext context)
        {
            try
            {
                var authHeader = context.HttpContext.Request.Headers["Authorization"].ToString();

                if (string.IsNullOrEmpty(authHeader) || !authHeader.StartsWith("Bearer "))
                    return false;

                var token = authHeader.Replace("Bearer ", string.Empty);

                if (token == "undefined")
                    return false;

                var handler = new JwtSecurityTokenHandler();
                var jwtToken = handler.ReadToken(token) as JwtSecurityToken;

                if (jwtToken == null || jwtToken.ValidTo < DateTime.UtcNow)
                    return false;

                var validationParameters = _jwtBearerOptions.TokenValidationParameters;

                var principal = handler.ValidateToken(token, validationParameters, out SecurityToken validatedToken);

                if (principal?.Identity is ClaimsIdentity identity && identity.IsAuthenticated)
                {
                    return true;
                }

                return false;
            }
            catch (SecurityTokenException ex)
            {
                return false;
            }
            catch (Exception ex)
            {
                return false;
            }
        }
    }
}
